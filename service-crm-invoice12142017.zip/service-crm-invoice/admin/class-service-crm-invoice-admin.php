<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/admin
 * @author     Rodney Olivier <rodneyolivier@live.com>
 */
class Service_Crm_Invoice_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Service_Crm_Invoice_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Service_Crm_Invoice_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name . '-data-tables', plugin_dir_url(__FILE__) . 'css/DataTablesCustom/datatables.min.css', array(), $this->version, 'all');

        wp_enqueue_style('wp-color-picker');

        wp_enqueue_style($this->plugin_name . '-jquery-ui-css', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/redmond/jquery-ui.css', array(), $this->version, 'all');

        wp_enqueue_style($this->plugin_name . '-admin-css', plugin_dir_url(__FILE__) . 'css/service-crm-invoice-admin.css', array('wp-color-picker'), $this->version, 'all');

        wp_enqueue_style($this->plugin_name . '-font-Arizonia', 'http://fonts.googleapis.com/css?family=Arizonia', array(), $this->version, 'all');
        
        wp_enqueue_style($this->plugin_name . '-font-Courgette', 'http://fonts.googleapis.com/css?family=Courgette', array(), $this->version, 'all');
        
        wp_enqueue_style($this->plugin_name . '-font-Roboto', 'http://fonts.googleapis.com/css?family=Roboto:400i', array(), $this->version, 'all');
        
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Service_Crm_Invoice_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Service_Crm_Invoice_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        wp_enqueue_media();

        
        wp_enqueue_script($this->plugin_name . '-masked-input-js', plugin_dir_url(__FILE__) . 'js/jquery.maskedinput.min.js', array('jquery'), $this->version, false);

        wp_enqueue_script($this->plugin_name . '-jquery-ui-js', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js', array('jquery'), $this->version, false);

        wp_enqueue_script($this->plugin_name . '-datatable-js', plugin_dir_url(__FILE__) . 'css/DataTablesCustom/datatables.min.js', array('jquery'), $this->version, false);

        wp_enqueue_script($this->plugin_name . '-admin-js', plugin_dir_url(__FILE__) . 'js/service-crm-invoice-admin.js', array('jquery', 'wp-color-picker'), $this->version, false);

    }

    public function add_plugin_admin_menu() {

        /*
         * Add a settings page for this plugin to the Settings menu.
         *
         * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
         *
         *        Administration Menus: http://codex.wordpress.org/Administration_Menus
         *
         */
        //add_options_page( 'Service Crm Invoice', 'SCI_Menu', 'manage_options', $this->plugin_name, array($this, 'display_plugin_setup_page'));
        //add_menu_page( string $page_title, string $menu_title, string $capability, string $menu_slug, callable $function = '', string $icon_url = '', int $position = null )
        add_menu_page('Service Crm Invoice', 'SCI_Menu', 'manage_options', 'service_crm_invoice_menu', '');

        add_submenu_page('service_crm_invoice_menu', __('Settings', 'service-crm-invoice-menu'), __('Settings', 'service-crm-invoice-menu'), 'manage_options', 'settings-page', array($this, 'service_crm_invoice_settings_page'));

        // Add a submenu to the custom top-level menu:
        add_submenu_page('service_crm_invoice_menu', __('Companies', 'service-crm-invoice-menu'), __('Companies', 'service-crm-invoice-menu'), 'manage_options', 'company-page', array($this, 'service_crm_invoice_companies_page'));

        // Add a second submenu to the custom top-level menu:
        add_submenu_page('service_crm_invoice_menu', __('Properties', 'service-crm-invoice-menu'), __('Properties', 'service-crm-invoice-menu'), 'manage_options', 'properties-page', array($this, 'service_crm_invoice_properties_page'));

        // Add a forth submenu to the custom top-level menu:
        add_submenu_page('service_crm_invoice_menu', __('Invoices', 'service-crm-invoice-menu'), __('Invoices', 'service-crm-invoice-menu'), 'manage_options', 'invoices-page', array($this, 'service_crm_invoice_invoices_page'));

        remove_submenu_page('service_crm_invoice_menu', 'service_crm_invoice_menu');
    }

    /**
     * Render the settings page for this plugin.
     *
     * @since    1.0.0
     */

    public function service_crm_invoice_settings_page() {
        global $wpdb;
        echo "<h2>" . __('Service CRM Settings', 'service-crm-menu') . "</h2>";

        $table_name = $wpdb->prefix . 'service_crm_invoice_settings';
        $select_service_crm_settings = $wpdb->get_results(
        "
            SELECT id, logo_url, title_name, title_tag, address1, address2, city, state, zip, phone1, phone2, fax
            FROM $table_name
            LIMIT 1
        "
        );

        if (!empty($select_service_crm_settings)) {
            foreach ($select_service_crm_settings as $setting) {
                $id = $setting->id;
                $logo_url = $setting->logo_url;
                $title_name = $setting->title_name;
                $title_tag = $setting->title_tag;
                $address1 = $setting->address1;
                $address2 = $setting->address2;
                $city = $setting->city;
                $state = $setting->state;
                $zip = $setting->zip;
                $phone1 = $setting->phone1;
                $phone2 = $setting->phone2;
                $fax = $setting->fax;
            }
        } else {
            $id = 0;
            $logo_url = "";
            $title_name = "";
            $title_tag = "";
            $address1 = "";
            $address2 = "";
            $city = "";
            $state = "";
            $zip = "";
            $phone1 = "";
            $phone2 = "";
            $fax = "";
        }
        $login_logo_id = '';
        $login_logo_url = '';
        include_once( 'partials/service-crm-invoice-admin-settings-display.php' );
    }

    /**
    * List Companies and Add new Companies from this method.
    *
    * @ since  1.0.0
    */
    
    public function service_crm_invoice_list_companies_page($select_service_crm_companies = null, $module = 'company', $add_new_invoice = null) {
        // Show list of properties to select from for editing.
        /* var_dump($_POST); */
        if ($module == 'invoice') {
            $url_get_vars = 'admin.php?page=invoices-page';
            $page_title = 'Select Company to Assign';
            $show_addnew_button = false;
            $page_action = 'service_crm_invoice_edit_invoice';
        } elseif ($module == 'company') {
            $url_get_vars = 'admin.php?page=company-page';
            $page_title = 'Select Company to Edit';
            $show_addnew_button = true;
            $page_action = 'service_crm_invoice_edit_company';
        } elseif ($module == 'invoice_public') {
            $url_get_vars = '';
            $page_title = 'Select Company';
            $show_addnew_button = false;
            $page_action = 'service_crm_invoice_select_company';
        }

        // need to accomidate if we are in the admin or public side of the site. or re-create these functions in the publice class.
        ?>
        <div class="wrap">
            <h2>
        <?php echo $page_title; ?>
            </h2>
        <?php
        if ($show_addnew_button) {
            echo "&nbsp;<a class='ui-button ui-widget ui-corner-all' href='" . admin_url('admin.php') . "?page=company-page&company_add_new=true' > Add New </a>";
        }
        ?>
            <br/>
            <div class='data_table_wrap'>
                <form id="service_crm_invoice_company_list_form" action="
            <?php
            if ($module == 'invoice_public') {
                echo esc_url($url_get_vars);
            } else {
                echo esc_url(admin_url($url_get_vars));
            }
            ?>" method="post">
                    <input type="hidden" id="service_crm_invoice_company_id" name="company_id" value="" />
                    <input type="hidden" name="action" value="<?php echo $page_action; ?>" />
                    <input type="hidden" name="add_new_invoice" value="<?php echo $add_new_invoice; ?>" />
                    <table id="service_crm_invoice_customer_datatable" >
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Company</th>
                                <th>Address1</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($select_service_crm_companies as $company) {
                        ?>
                                <tr>
                                    <td><input class="service_crm_invoice_company_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $company->id; ?>" type="button" value="Select Company" /></td> 
                                    <td><?php echo $company->name; ?></td>
                                    <td><?php echo $company->address1; ?></td>
                                </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
        <?php
    }

    /**
    * Render Company form for new and existing Companies.
    *
    * @ since  1.0.0
    */
    
    public function service_crm_invoice_companies_page() {
        global $wpdb;
        //manage direction to add a new company or edit an existing company
        if (isset($_GET['company_add_new']) && $_GET['company_add_new'] == 'true') {
            $add_new = true;
        } else {
            $add_new = false;
        }

        $table_name = $wpdb->prefix . 'service_crm_invoice_company';
        $new_company = 'false';
        if (!empty($_POST['company_id']) && $_POST['company_id'] != '0') {
            $where = " WHERE id = '" . $_POST['company_id'] . "'";
        } else {
            $where = " WHERE 1";
        }
        $select_service_crm_companies = $wpdb->get_results(
        "
            SELECT id, name, user_id, address1, address2, address3, city, state, zip, country, phone1, phone2, phone3, fax, note1, note2, url
            FROM $table_name 
            $where
        "
        );

        if (($add_new === false) && (count($select_service_crm_companies) >= 1) && (!isset($_POST['company_id']) )) {
            // list companies to select
            $this->service_crm_invoice_list_companies_page($select_service_crm_companies);
        } elseif (( count($select_service_crm_companies) == 0 ) || ($add_new === true)) {
            // setup for blank form and accept data for a new company

            $id = '0';
            $name = $company->name;
            $user_id = "";
            $address1 = "";
            $address2 = "";
            $address3 = "";
            $city = "";
            $state = "";
            $zip = "";
            $country = "";
            $phone1 = "";
            $phone2 = "";
            $phone3 = "";
            $fax = "";
            $note1 = "";
            $note2 = "";
            $url = "";

            $new_company = 'true';
            $page_title = "New Company";
            $page_action = "service_crm_invoice_company_update";
            include_once( 'partials/service-crm-invoice-admin-companies-display.php' );
        } elseif (count($select_service_crm_companies) == 1) {
            // setup form for editing this company data

            foreach ($select_service_crm_companies as $company) {
                $company_id = $company->id;
                $company_name = $company->name;
                $company_user_id = $company->user_id;
                $company_user_name = $this->get_user_select($company_user_id, false, true);
                $company_address1 = $company->address1;
                $company_address2 = $company->address2;
                $company_address3 = $company->address3;
                $company_city = $company->city;
                $company_state = $company->state;
                $company_zip = $company->zip;
                $company_country = $company->country;
                $company_phone1 = $company->phone1;
                $company_phone2 = $company->phone2;
                $company_phone3 = $company->phone3;
                $company_fax = $company->fax;
                $company_note1 = $company->note1;
                $company_note2 = $company->note2;
                $company_url = $company->url;
                break;
            }
            $new_company = 'false';
            $page_title = "Edit Company id = " . $company_id;
            $page_action = 'service_crm_invoice_edit_company';
            include_once( 'partials/service-crm-invoice-admin-companies-display.php' );
        }
    }

    /**
    * List Properties associated with Companies from this method.
    *
    * @ since  1.0.0
    */
    
    public function service_crm_invoice_list_properties_page($select_service_crm_invoice_properties, $module = 'properties', $company_id = null, $add_new_invoice = null) {
        // Show list of properties to select from for editing.
        if ($module == 'invoice') {
            $url_get_vars = 'admin.php?page=invoices-page';
            $page_title = 'Select Property to Assign';
            if (count($select_service_crm_invoice_properties) === 0) {
                $show_addnew_button = true;
            } else {
                $show_addnew_button = false;
            }
            $page_action = 'service_crm_invoice_edit_invoice';
            if (!empty($company_id)) {
                $set_company_id = true;
            } else {
                $set_company_id = false;
            }
        } elseif ($module == 'properties') {
            $url_get_vars = 'admin.php?page=properties-page';
            $page_title = 'Select property to Edit ';
            $show_addnew_button = true;
            $page_action = 'service_crm_invoice_property_edit';
            $set_company_id = false;
        } elseif ($module == 'invoice_public') {
            $url_get_vars = '';
            $page_title = 'Select Property';
            $show_addnew_button = false;
            $page_action = 'service_crm_invoice_select_company';
            $set_company_id = true;
        }
        ?>
        <div class="wrap">
            <h2><?php echo $page_title; ?></h2>
            <?php
            if ($show_addnew_button) {
                echo "<a class='ui-button ui-widget ui-corner-all' href='" . admin_url('admin.php') . "?page=properties-page&property_add_new=true'> Add New </a>";
            }
            ?>
            <br/>
            <form id="service_crm_invoice_property_list_form" action="
            <?php
                if ($module == 'invoice_public') {
                    echo esc_url($url_get_vars);
                } else {
                    echo esc_url(admin_url($url_get_vars));
                }
            ?>" method="post">
                <input type="hidden" id="service_crm_invoice_property_id" name="property_id" value="" />
                <input type="hidden" name="action" value="<?php echo $page_action; ?>" />
                <input type="hidden" name="add_new_invoice" value="<?php echo $add_new_invoice; ?>" />
            <?php
                if ($set_company_id) {
                    echo "<input type='hidden' id='service_crm_invoice_property_list_company_id' name='company_id' value='" . $company_id . "' />";
                }
                ?>
                <table id="service_crm_invoice_property_datatable" >
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Company Name</th>
                            <th>Property Name </th>
                            <th>Address1</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($select_service_crm_invoice_properties as $property) {
                        ?>
                        <tr>
                            <td><input class="service_crm_invoice_property_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $property->id; ?>" type="button" value="Select Property" /></td> 
                            <td><?php echo $this->service_crm_invoice_get_company_name($property->company_id); ?></td>
                            <td><?php echo $property->name; ?></td>
                            <td><?php echo $property->address1; ?></td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </form>
        </div>
    <?php
    }
    
    /**
    * Render Property form for new and existing properties.
    *
    * @ since  1.0.0
    */
    public function service_crm_invoice_properties_page() {
        global $wpdb;
        //manage direction to add a new property or edit an existing property
        if (isset($_GET['property_add_new']) && $_GET['property_add_new'] == 'true') {
            $add_new = true;
        } else {
            $add_new = false;
        }
        if (isset($_POST['property_id']) && intval($_POST['property_id']) != 0) {
            $where = ' WHERE id = ' . $_POST['property_id'];
        } else {
            $where = ' WHERE 1';
        }

        $table_name = $wpdb->prefix . 'service_crm_invoice_properties';
        $select_service_crm_invoice_properties = $wpdb->get_results(
        "
            SELECT id, company_id, name, address1, address2, address3, city, state, zip, country, phone1, phone2, note1, note2
            FROM $table_name
            $where
        "
        );
        if (($add_new === false) && (count($select_service_crm_invoice_properties) >= 1) && (!isset($_POST['property_id']))) {
            // show list of properties to select for editing.
            $this->service_crm_invoice_list_properties_page($select_service_crm_invoice_properties);
        } elseif ((count($select_service_crm_invoice_properties) == 0) || ($add_new === true)) {
            // setup form to add a new property
            $property_id = '0';
            $property_company_id = '';
            $property_name = '';
            $property_address1 = '';
            $property_address2 = '';
            $property_address3 = '';
            $property_city = '';
            $property_state = '';
            $property_zip = '';
            $property_country = '';
            $property_phone1 = '';
            $property_phone2 = '';
            $property_note1 = '';
            $property_note2 = '';

            $new_property = 'true';
            $page_title = "New Property";
            $page_action = 'service_crm_invoice_property_update';
            include_once( 'partials/service-crm-invoice-admin-properties-display.php' );
        } else {
            // setup form to edit this propery
            foreach ($select_service_crm_invoice_properties as $property) {
                $property_id = $property->id;
                $property_company_id = $property->company_id;
                $property_name = $property->name;
                $property_address1 = $property->address1;
                $property_address2 = $property->address2;
                $property_address3 = $property->address3;
                $property_city = $property->city;
                $property_state = $property->state;
                $property_zip = $property->zip;
                $property_country = $property->country;
                $property_phone1 = $property->phone1;
                $property_phone2 = $property->phone2;
                $property_note1 = $property->note1;
                $property_note2 = $property->note2;
                break;
            }
            $new_property = 'false';
            $page_title = "Edit Property";
            $page_action = 'service_crm_invoice_property_update';
            include_once( 'partials/service-crm-invoice-admin-properties-display.php' );
        }
    }

    /**
    * List Invoices associated with Properties that are associate with Companies from this method.
    *
    * @ since  1.0.0
    */
    public function service_crm_invoice_list_invoice_page($service_crm_invoice_invoices, $company_id = null, $property_id = null) {
        // Show list of invoices to select from for editing.
        $url_get_vars = 'admin.php?page=invoices-page';
        $page_title = 'Select Invoice to Edit ';
        $show_addnew_button = true;
        $page_action = 'service_crm_invoice_edit_invoice';
        ?>
        <div class="wrap">
            <h2><?php echo $page_title; ?></h2>
            <?php
            if ($show_addnew_button) {
                echo "<input type='button' class='ui-button ui-widget ui-corner-all' id='service_crm_invoice_invoice_add_new' value='Add New Invoice' />";
            }
            ?>
            <br/>
            <!-- check the value set by show_addnew_button -->			
            <form id="service_crm_invoice_invoices_list_form" action="<?php echo esc_url(admin_url($url_get_vars)); ?>" method="post">
                <input type="hidden" name="action" value="<?php echo $page_action; ?>" />
                <input type="hidden" id='service_crm_invoice_invoice_add_new_invoice' name="add_new_invoice" value="" />
                <input type="hidden" id="service_crm_invoice_property_id" name="property_id" value="<?php echo $property_id; ?>" />
                <input type='hidden' id='service_crm_invoice_company_id' name='company_id' value='<?php echo $company_id; ?>' />
                <input type='hidden' id='service_crm_invoice_invoice_id' name='invoice_id' value='' />
                <table id="service_crm_invoice_invoice_datatable" >
                    <thead>
                        <tr>
                            <th>Select</th>
                            <th>Company</th>
                            <th>Property</th>
                            <th>Invoice Num.</th>
                            <th>Invoice Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($service_crm_invoice_invoices as $invoice) { /* <input class="service_crm_invoice_invoice_list_submit" company_id="<?php echo $invoice->company_id; ?>" property_id="<?php echo $invoice->property_id; ?>" invoice_id="<?php echo $invoice->id ?>" type="button" value="Select Invoice" /> */
                        ?>
                            <tr>
                                <td><input class="service_crm_invoice_invoice_list_submit ui-button ui-widget ui-corner-all" invoice_id="<?php echo $invoice->id ?>" type="button" value="Select Invoice" /></td> 
                                <td><?php echo $this->service_crm_invoice_get_company_name($invoice->company_id); ?></td>
                                <td><?php echo $this->service_crm_invoice_get_property_name($invoice->property_id); ?></td>
                                <td><?php echo $invoice->invoice_number; ?></td>
                                <td><?php echo date('m/d/Y', strtotime($invoice->invoice_date)); ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </form>
        </div>
        <?php
    }

    /**
    * Render Invoice form for new and existing invoices.
    *  In this method you must select a Company to setup a list of associated Properties.
    *  You must then select a Property to setup a list of associated Invoices.
    *  Then you must select an Invoice or select the Add New Invoice button to render the Invoice form.
    *
    *  This method also handles a redirect from both Edit and New Invoice when a duplicate invoice number is detected in Invoice Update.
    * @ since  1.0.0
    */
    public function service_crm_invoice_invoices_page() {
        global $wpdb;
echo '<pre>';
var_dump($_POST);
echo '</pre>';
        /**
        *  Manage method if invoice number is not unique.
        **/
        if (isset($_GET['redirect']) && $_GET['redirect'] == 'true') {
            $service_crm_invoice_session_val = '';
            if (isset($_GET['company_id']) && isset($_GET['property_id']) && isset($_GET['invoice_number'])) {
                $postVal = $this->service_crm_invoice_get_session_val($_GET['company_id'], $_GET['property_id'], $_GET['invoice_number']); // results or false
                $service_crm_invoice_session_id = $postVal['sessionId'];
                $service_crm_invoice_session_val = $postVal['postVal'];
            }
        }
        
        /**
         *  Get a list of Companies to select the top-level hierarch of the invoice you will edit/create. 
        **/
        if (empty($_POST) && (!isset($service_crm_invoice_session_val) || empty($service_crm_invoice_session_val) )) {
            // 1st entry from Invoice Menu
            $select_service_crm_companies = $this->service_crm_invoice_get_company_data();
            if (isset($_GET['invoice_add_new']) && $_GET['invoice_add_new'] == 'true') {
                $add_new_invoice = true;
            } else {
                $add_new_invoice = false;
            }

            $this->service_crm_invoice_list_companies_page($select_service_crm_companies, 'invoice', $add_new_invoice);
        }
        /*
         * List properties associated with the previously selected company
         */
        if (isset($_POST['company_id']) &&
                !isset($_POST['property_id']) &&
                !isset($_POST['invoice_id'])) {
            $company_id = $_POST['company_id']; // from prevous loop
            $property_id = null;
            $select_service_crm_properties = $this->service_crm_invoice_get_property_data($property_id, $company_id);
            if (isset($_POST['add_new_invoice'])) {
                $add_new_invoice = $_POST['add_new_invoice'];
            } else {
                $add_new_invoice = false;
            }
            $this->service_crm_invoice_list_properties_page($select_service_crm_properties, 'invoice', $company_id, $add_new_invoice);
        }
        /*
         * Manage setup for new invoices or managing instance of redirect from invoice number is not unique
         */
        if (( isset($_POST['company_id']) &&
                isset($_POST['property_id']) &&
                (!isset($_POST['invoice_id']) || empty($_POST['invoice_id']) ) ) ||
                ( isset($service_crm_invoice_session_val['company_id']) &&
                isset($service_crm_invoice_session_val['property_id']) &&
                (!isset($service_crm_invoice_session_val['invoice_id']) || empty($post_val['invoice_id']) ) )
        ) {

            if (isset($_POST['company_id']) && !isset($service_crm_invoice_session_val)) {
                $company_id = $_POST['company_id'];
                $property_id = $_POST['property_id'];
                $service_crm_invoice_invoices = $this->service_crm_invoice_get_invoice_data(null, $property_id);
            } else {
                $company_id = $service_crm_invoice_session_val['company_id'];
               $property_id = $service_crm_invoice_session_val['property_id'];
            }
            // are there any invoices for this property
            //$service_crm_invoice_invoices = $this->service_crm_invoice_get_invoice_data(null, $property_id);
            if (( isset($service_crm_invoice_session_val) ) ||
                    ( count($service_crm_invoice_invoices) === 0 ||
                    ( isset($_POST['add_new_invoice']) && !empty($_POST['add_new_invoice'])) )
            ) {
                if (isset($service_crm_invoice_session_val) && !empty($service_crm_invoice_session_val)) {
                    $invoice_id = $service_crm_invoice_session_val['id'];
                    $invoice_number = $service_crm_invoice_session_val['invoice_number'];
                    $invoice_date = $service_crm_invoice_session_val['invoice_date'];
                    $salesperson = $service_crm_invoice_session_val['salesperson'];
                    $po_number = $service_crm_invoice_session_val['po_number'];
                    $requisitioner = $service_crm_invoice_session_val['requisitioner'];
                    $fob_point = $service_crm_invoice_session_val['fob_point'];
                    $terms = $service_crm_invoice_session_val['terms'];

                    $quantity_array = '[';
                    $description_array = '[';
                    $unitprice_array = '[';
                    $totalprice_array = '[';
                    $x = count($service_crm_invoice_session_val['quantity']);
                    $y = 1;
                    foreach ($service_crm_invoice_session_val['quantity'] as $quantity) {
                        $quantity_array .= '"' . $quantity . '"';
                        if ($y < $x) {
                            $quantity_array .= ',';
                            $y++;
                        }
                    }
                    $y = 1;
                    foreach ($service_crm_invoice_session_val['description'] as $description) {
                        $description_array .= '"' . $description . '"';
                        if ($y < $x) {
                            $description_array .= ',';
                            $y++;
                        }
                    }
                    $y = 1;
                    foreach ($service_crm_invoice_session_val['unitprice'] as $unitprice) {
                        $unitprice_array .= '"' . $unitprice . '"';
                        if ($y < $x) {
                            $unitprice_array .= ',';
                            $y++;
                        }
                    }
                    $y = 1;
                    foreach ($service_crm_invoice_session_val['totalprice'] as $totalprice) {
                        $totalprice_array .= '"' . $totalprice . '"';
                        if ($y < $x) {
                            $totalprice_array .= ',';
                            $y++;
                        }
                    }
                    $quantity_array .= ']';
                    $description_array .= ']';
                    $unitprice_array .= ']';
                    $totalprice_array .= ']';
                    $invoice_details_json = '{
                        "quantity":' . $quantity_array . ',
                        "description":' . $description_array . ',
                        "unitprice":' . $unitprice_array . ',
                        "totalprice":' . $totalprice_array . ',
                        "subtotal":"' . $service_crm_invoice_session_val['subtotal'] . '",
                        "sales_tax":"' . $service_crm_invoice_session_val['sales_tax'] . '",
                        "ship_handle":"' . $service_crm_invoice_session_val['ship_handle'] . '",
                        "grand_total":"' . $service_crm_invoice_session_val['grand_total'] . '"
                    }';

                    $pay_status = $service_crm_invoice_session_val['pay_status'];
                    $comments = $service_crm_invoice_session_val['comments'];
                    $agreement_type = $service_crm_invoice_session_val['agreement_type'];
                    $invoice_type = $service_crm_invoice_session_val['invoice_type'];
                    $invoice_due_date = $service_crm_invoice_session_val['invoice_due_date'];
                    echo "<div class='error notice-error'><h1>The invoice number: $invoice_number already exists. Please use a differant number.</h1></div>";
                } else {
                    $invoice_id = '0';
                    $company_id = $_POST['company_id'];
                    $property_id = $_POST['property_id'];
                    $invoice_number = '';
                    $invoice_date = '';
                    $salesperson = '';
                    $po_number = '';
                    $requisitioner = '';
                    $fob_point = '';
                    $terms = '';

                    $invoice_details_json = '{
                        "quantity":["0"],
                        "description":[""],
                        "unitprice":["0.00"],
                        "totalprice":["0.00"],
                        "subtotal":"0.00",
                        "sales_tax":"0.00",
                        "ship_handle":"0.00",
                        "grand_total":"0.00"
                    }';
                    $pay_status = 'unpaid';
                    $comments = '';
                    $agreement_type = '';
                    $invoice_type = '';
                    $invoice_due_date = '';
                }

                if ($invoice_id !== '0') {
                    $new_invoice = false;
                    $page_title = 'Edit Invoice ' . $invoice_id;
echo('$invoice_id !== 0');
//die(var_dump($invoice_id));
                } else {
                    $new_invoice = true;
                    $page_title = 'New Invoice';
echo('else');
//die(var_dump($invoice_id, $new_invoice));
                }
                $invoice_details_array = json_decode($invoice_details_json, true);
                $quantity_array = $invoice_details_array['quantity'];
                $description_array = $invoice_details_array['description'];
                $unitprice_array = $invoice_details_array['unitprice'];
                $totalprice_array = $invoice_details_array['totalprice'];
                $subtotal = $invoice_details_array['subtotal'];
                $sales_tax = $invoice_details_array['sales_tax'];
                $ship_handle = $invoice_details_array['ship_handle'];
                $grand_total = $invoice_details_array['grand_total'];
                $num_to_words = new Numbers_Words();
                $numWordsGrandTotal = $num_to_words->toCurrency($grand_total, "en_US", "USD");
                $company_array = $this->service_crm_invoice_get_company_data($company_id);
                $property_array = $this->service_crm_invoice_get_property_data($property_id);

                $page_action = 'service_crm_invoice_invoice_update';
                $select_service_crm_invoice_settings = $this->service_crm_invoice_get_settings();

                if (isset($service_crm_invoice_session_id)) {
                    $this->service_crm_invoice_unset_session_val($service_crm_invoice_session_id);
                }

                include_once( 'partials/service-crm-invoice-admin-invoices-display.php' );
                exit;
            } else {
                $add_new_invoice = false;
                $service_crm_invoice_invoices = $this->service_crm_invoice_get_invoice_data(null, $property_id);
                $this->service_crm_invoice_list_invoice_page($service_crm_invoice_invoices, $company_id, $property_id);
            }
        }
        /*
         * Manage setup for edit a selected existing invoice.
         */
        if (isset($_POST['company_id']) && isset($_POST['property_id']) && isset($_POST['invoice_id'])) {
            $add_new_invoice = false;
            $service_crm_invoice_invoices = $this->service_crm_invoice_get_invoice_data($_POST['invoice_id'], null);
            foreach ($service_crm_invoice_invoices as $invoice) {
                $invoice_id = $invoice->id;
                $company_id = $invoice->company_id;
                $property_id = $invoice->property_id;
                $invoice_number = $invoice->invoice_number;
                $invoice_date = $invoice->invoice_date;
                $salesperson = $invoice->salesperson;
                $po_number = $invoice->po_number;
                $requisitioner = $invoice->requisitioner;
                $fob_point = $invoice->fob_point;
                $terms = $invoice->terms;
                $pay_status = $invoice->pay_status;
                $comments = $invoice->comments;
                $agreement_type = $invoice->agreement_type;
                $invoice_type = $invoice->invoice_type;
                $invoice_due_date = $invoice->invoice_due_date;
                $invoice_details_json = $invoice->invoice_details;
            }

            $invoice_details_array = json_decode($invoice_details_json, true);
            $quantity_array = array();
            $description_array = array();
            $unitprice_array = array();
            $total_array = array();
            $x = 0;
            foreach ($invoice_details_array["quantity"] as $ar_item) {
                $quantity_array[$x] = $ar_item;
                $x++;
            }
            $x = 0;
            foreach ($invoice_details_array["description"] as $ar_item) {
                $description_array[$x] = $ar_item;
                $x++;
            }
            $x = 0;
            foreach ($invoice_details_array["unitprice"] as $ar_item) {
                $unitprice_array[$x] = $ar_item;
                $x++;
            }
            $x = 0;
            foreach ($invoice_details_array["totalprice"] as $ar_item) {
                $totalprice_array[$x] = $ar_item;
                $x++;
            }
            $invoice_details_array['quantity'] = $quantity_array;
            $invoice_details_array['description'] = $description_array;
            $invoice_details_array['unitprice'] = $unitprice_array;
            $invoice_details_array['totalprice'] = $totalprice_array;
            $new_invoice = false;
            $page_title = 'Edit Invoice ' . $invoice_id;

            $quantity_array = $invoice_details_array['quantity'];
            $description_array = $invoice_details_array['description'];
            $unitprice_array = $invoice_details_array['unitprice'];
            $totalprice_array = $invoice_details_array['totalprice'];
            $subtotal = $invoice_details_array['subtotal'];
            $sales_tax = $invoice_details_array['sales_tax'];
            $ship_handle = $invoice_details_array['ship_handle'];
            $grand_total = $invoice_details_array['grand_total'];
            $num_to_words = new Numbers_Words();
            $numWordsGrandTotal = $num_to_words->toCurrency($grand_total, "en_US", "USD");

            $company_array = $this->service_crm_invoice_get_company_data($company_id);
            $property_array = $this->service_crm_invoice_get_property_data($property_id);

            $page_action = 'service_crm_invoice_invoice_update';
            $select_service_crm_invoice_settings = $this->service_crm_invoice_get_settings();

            include_once( 'partials/service-crm-invoice-admin-invoices-display.php' );
        }
    }

    /**
     * Add settings action link to the plugins page.
     *
     * @since    1.0.0
     */
    public function add_action_links($links) {
        /*
         *  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
         */

        //admin.php?page=settings-page
        $settings_link = array(
            '<a href="' . admin_url('admin.php?page=settings-page') . '">' . __('Settings', $this->plugin_name) . '</a>'
        );
        return array_merge($settings_link, $links);
    }

    
    /*
     * Manage inserting or updating settings
     */
    function service_crm_invoice_setting_update() {
        global $wpdb;

        if (!empty($_POST)) {
            $id = $_POST['id'];
            $logo_url = $_POST['logo_url'];
            $title_name = $_POST['title_name'];
            $title_tag = $_POST['title_tag'];
            $address1 = $_POST['address1'];
            $address2 = $_POST['address2'];
            $city = $_POST['city'];
            $state = $_POST['state'];
            $zip = $_POST['zip'];
            $phone1 = $_POST['phone1'];
            $phone2 = $_POST['phone2'];
            $fax = $_POST['fax'];
        } else {
            return false;
        }
        $table_name = $wpdb->prefix . 'service_crm_invoice_settings';
        if (is_admin()) {
            if ($id == '0') {
                $wpdb->query($wpdb->prepare(
                    "
                    INSERT INTO $table_name
                    ( 
                            logo_url,
                            title_name,
                            title_tag,
                            address1,
                            address2,
                            city,
                            state,
                            zip,
                            phone1,
                            phone2,
                            fax
                    )
                    VALUES
                    (
                            %s, 
                            %s,
                            %s,
                            %s,
                            %s,
                            %s, 
                            %s,
                            %s,
                            %s,
                            %s, 
                            %s
                    )
                    ", $logo_url, $title_name, $title_tag, $address1, $address2, $city, $state, $zip, $phone1, $phone2, $fax
                ));
                if ($wpdb->insert_id === false) {
                    $wpdb->show_errors();
                } else {
                    add_action('admin_notices', 'my_db_success_notice');
                    wp_redirect(admin_url()); //$_SERVER['HTTP_REFERER'] );
                    exit();
                }
            } else {

                //var_dump($id);
                $result = $wpdb->update(
                        $table_name, array(
                    'logo_url' => $logo_url, // string
                    'title_name' => $title_name,
                    'title_tag' => $title_tag,
                    'address1' => $address1, // string
                    'address2' => $address2,
                    'city' => $city,
                    'state' => $state,
                    'zip' => $zip,
                    'phone1' => $phone1,
                    'phone2' => $phone2,
                    'fax' => $fax
                        ), array('id' => $id), array(
                    '%s', // value1
                    '%s', // value2
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s'
                        ), array('%d')
                );

                if ($result === false) {
                    // send a message that we failed;
                    add_action('admin_notices', 'my_db_error_notice');
                } else {
                    // send a message that we where successful
                    add_action('admin_notices', 'my_db_success_notice');
                    wp_redirect(admin_url()); //$_SERVER['HTTP_REFERER'] );
                    exit();
                }
            }
        }
    }

    /*
     * Manage insert new companie of update an existing company
     */
    function service_crm_invoice_company_update() {
        global $wpdb;

        if (is_admin()) {
            /* echo "<pre>";
              var_dump($_POST['id']); die('HERE');
              echo "</pre>"; */
            if (isset($_POST['id'])) {
                $id = $_POST['id'];
                $name = $_POST['name'];
                if (!empty($_POST['user_id'])) {
                    $user_id = $_POST['user_id'];
                } else {
                    $user_id = '0';
                }
                $address1 = $_POST['address1'];
                $address2 = $_POST['address2'];
                $address3 = $_POST['address3'];
                $city = $_POST['city'];
                $state = $_POST['state'];
                $zip = $_POST['zip'];
                $country = $_POST['country'];
                $phone1 = $_POST['phone1'];
                $phone2 = $_POST['phone2'];
                $phone3 = $_POST['phone3'];
                $fax = $_POST['fax'];
                $url = $_POST['url'];
                $note1 = $_POST['note1'];
                $note2 = $_POST['note2'];
            }
            $table_name = $wpdb->prefix . "service_crm_invoice_company";
            if (!empty($_POST['company_add_new']) && $_POST['company_add_new'] == 'false') {
                // from edit company
                if (intval($id) !== 0) {
                    $result = $wpdb->update(
                            $table_name, array(
                        'name' => $name, // string
                        'user_id' => $user_id, // integer (number) 
                        'address1' => $address1, // string
                        'address2' => $address2,
                        'address3' => $address3,
                        'city' => $city,
                        'state' => $state,
                        'zip' => $zip,
                        'country' => $country,
                        'phone1' => $phone1,
                        'phone2' => $phone2,
                        'phone3' => $phone3,
                        'fax' => $fax,
                        'url' => $url,
                        'note1' => $note1,
                        'note2' => $note2
                            ), array('ID' => $id), array(
                        '%s', // value1
                        '%d', // value2
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s'
                            ), array('%d')
                    );

                    if ($result === false) {
                        // send a message that we failed;
                        add_action('admin_notices', 'my_db_error_notice');
                    } else {
                        // send a message that we where successful
                        add_action('admin_notices', 'my_db_success_notice');
                        wp_redirect(admin_url()); //$_SERVER['HTTP_REFERER'] );
                        exit();
                    }
                } else {
                    echo "<div class='notice error_notice'>Error: id 0 is not a valid record id. </div>";
                }
            } else {
                // from add new company
                $wpdb->query($wpdb->prepare(
                "
                    INSERT INTO $table_name
                    ( 
                        user_id,
                        name,
                        address1,
                        address2,
                        address3,
                        city,
                        state,
                        zip,
                        country,
                        phone1,
                        phone2,
                        phone3,
                        fax,
                        url,
                        note1,
                        note2
                    )
                    VALUES
                    (
                        %d,
                        %s, 
                        %s,
                        %s,
                        %s,
                        %s, 
                        %s,
                        %s,
                        %s,
                        %s, 
                        %s,
                        %s,
                        %s,
                        %s, 
                        %s,
                        %s
                    )
                ", intval($user_id), $name, $address1, $address2, $address3, $city, $state, $zip, $country, $phone1, $phone2, $phone3, $fax, $url, $note1, $note2
                ));
                //var_dump($wpdb->last_query); die();
                if ($wpdb->insert_id === false) {
                    $wpdb->show_errors();
                } else {
                    add_action('admin_notices', 'my_db_success_notice');
                    wp_redirect(admin_url()); //$_SERVER['HTTP_REFERER'] );
                    exit();
                }
            }
        } else {
            echo "<div class='notice error_notice'>You Must be an admin to perform this function.</div>";
        }
    }

    /*
     * Manage insert new property or update existing property. 
     */
    function service_crm_invoice_property_update() {
        global $wpdb;
        /* echo "<pre>";
          var_dump($_POST); die(); */
        if (isset($_POST['id'])) {
            $id = $_POST['id'];
            $company_id = $_POST['company_id'];
            $name = $_POST['name'];
            $address1 = $_POST['address1'];
            $address2 = $_POST['address2'];
            $address3 = $_POST['address3'];
            $city = $_POST['city'];
            $state = $_POST['state'];
            $zip = $_POST['zip'];
            $country = $_POST['country'];
            $phone1 = $_POST['phone1'];
            $phone2 = $_POST['phone2'];
            $note1 = $_POST['note1'];
            $note2 = $_POST['note2'];
        }

        if (is_admin()) {
            $table_name = $wpdb->prefix . 'service_crm_invoice_properties';
            if (isset($_POST['proprty_add_new']) && $_POST['proprty_add_new'] == 'true') {
                // insert data into service_crm_invoice_properties table

                $wpdb->query($wpdb->prepare(
                "
                    INSERT INTO $table_name
                    ( 
                        company_id,
                        name,
                        address1,
                        address2,
                        address3,
                        city,
                        state,
                        zip,
                        country,
                        phone1,
                        phone2,
                        note1,
                        note2
                    )
                    VALUES
                    (
                        %d,
                        %s, 
                        %s,
                        %s,
                        %s,
                        %s, 
                        %s,
                        %s,
                        %s,
                        %s, 
                        %s,
                        %s,
                        %s
                    )
                ", intval($company_id), $name, $address1, $address2, $address3, $city, $state, $zip, $country, $phone1, $phone2, $note1, $note2
                ));
                if ($wpdb->insert_id === false) {
                    echo $wpdb->show_errors();
                    die();
                } else {
                    add_action('admin_notices', 'my_db_success_notice');
                    wp_redirect(admin_url()); //$_SERVER['HTTP_REFERER'] );
                    exit();
                }
            } else {
                // update data in service_crm_invoice_properties table for id = $_POST['id']
                if (intval($id) !== 0) {
                    $result = $wpdb->update(
                        $table_name, 
                        array(
                            'name' => $name, // string
                            'company_id' => intval($company_id), // integer (number) 
                            'address1' => $address1, // string
                            'address2' => $address2,
                            'address3' => $address3,
                            'city' => $city,
                            'state' => $state,
                            'zip' => $zip,
                            'country' => $country,
                            'phone1' => $phone1,
                            'phone2' => $phone2,
                            'note1' => $note1,
                            'note2' => $note2
                        ), array('id' => $id), array(
                            '%s', // value1
                            '%d', // value2
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s'
                        ), array('%d')
                    );

                    if ($result === false) {
                        // send a message that we failed;
                        add_action('admin_notices', 'my_db_error_notice');
                    } else {
                        // send a message that we where successful
                        add_action('admin_notices', 'my_db_success_notice');
                        wp_redirect(admin_url()); //$_SERVER['HTTP_REFERER'] );
                        exit();
                    }
                } else {
                    echo "<div class='notice error_notice'>Error: id 0 is not a valid record id. </div>";
                }
            }
        } else {
            echo "<div class='notice error_notice'>You must be an Administrator to perform this function.</div>";
        }
    }

    /*
     * Check for existing invoice number before save
     */
    function checkInvoiceNumber($invoice_number, $id = null) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'service_crm_invoice_invoices';
        if (!empty($id)) {
            $select_service_crm_invoices = $wpdb->get_results(
            "
                SELECT id, invoice_number
                FROM $table_name
                WHERE invoice_number = $invoice_number 
            "
            );
            foreach ($select_service_crm_invoices as $invoice) {
                if ($invoice_number == $invoice->invoice_number && $id == $invoice->id) {
                    // no changes have occured
                    return false;
                } elseif ($invoice_number == $invoice->invoice_number && $id != $invoice->id) {
                    return true;
                }
            }
        }

        $select_service_crm_invoices = $wpdb->get_results(
        "
            SELECT id, invoice_number
            FROM $table_name
            WHERE invoice_number = $invoice_number
        "
        );

        if (empty($select_service_crm_invoices)) {
            return false;
        } else {
            return true;
        }
    }

    /*function service_crm_invoice_return_to_invoice($postVal = null) {


        $invoice_id = $postVal['id'];
        $company_id = $postVal['company_id'];
        $property_id = $postVal['property_id'];
        $invoice_number = $postVal['invoice_number'];
        $invoice_date = $postVal['invoice_date'];
        $salesperson = $postVal['salesperson'];
        $po_number = $postVal['po_number'];
        $requisitioner = $postVal['requisitioner'];
        $fob_point = $postVal['fob_point'];
        $terms = $postVal['terms'];
        $pay_status = $postVal['pay_status'];
        $comments = $postVal['comments'];
        $invoice_details_json = $postVal['invoice_details'];

        $invoice_details_array = json_decode($invoice_details_json, true);

        $new_invoice = true;
        $page_title = 'New Invoice';

        $invoice_details_array = json_decode($invoice_details_json, true);
        $quantity_array = $invoice_details_array['quantity'];
        $description_array = $invoice_details_array['description'];
        $unitprice_array = $invoice_details_array['unitprice'];
        $totalprice_array = $invoice_details_array['totalprice'];
        $subtotal = $invoice_details_array['subtotal'];
        $sales_tax = $invoice_details_array['sales_tax'];
        $ship_handle = $invoice_details_array['ship_handle'];
        $grand_total = $invoice_details_array['grand_total'];

        $company_array = $this->service_crm_invoice_get_company_data($company_id);
        $property_array = $this->service_crm_invoice_get_property_data($property_id);

        $page_action = 'service_crm_invoice_invoice_update';
        $select_service_crm_invoice_settings = $this->service_crm_invoice_get_settings();

        include_once( 'partials/service-crm-invoice-admin-invoices-display.php' );
    }*/

    /*
     * Manage inserting new invoice or updating existing invoice
     * also manage instance of invoice number is not unique
     */
    function service_crm_invoice_invoice_update() {
        global $wpdb;
/*echo '<pre>';
var_dump($_POST);
echo '</pre>';
die();*/
        if (is_admin()) {
            if (!empty($_POST['action'])) {
                // prep invoice details
                $invoice_details = array('quantity' => $_POST['quantity'], 'description' => $_POST['description'], 'unitprice' => $_POST['unitprice'], 'totalprice' => $_POST['totalprice'], 'subtotal' => $_POST['subtotal'], 'sales_tax' => $_POST['sales_tax'], 'ship_handle' => $_POST['ship_handle'], 'grand_total' => $_POST['grand_total']);
                $invoice_details_json_encode = json_encode($invoice_details);
                $id = intval($_POST['id']);
                $company_id = intval($_POST['company_id']);
                $property_id = intval($_POST['property_id']);
                $invoice_number = intval($_POST['invoice_number']);
                $invoice_date = date('Y-m-d H:i:s', strtotime($_POST['invoice_date']));
                $salesperson = $_POST['salesperson'];
                $po_number = $_POST['po_number'];
                $requisitioner = $_POST['requisitioner'];
                $fob_point = $_POST['fob_point'];
                $terms = $_POST['terms'];
                $pay_status = $_POST['pay_status'];
                $comments = $_POST['comments'];
                $agreement_type = $_POST['agreement_type'];
                $invoice_type = $_POST['invoice_type'];
                $invoice_due_date = date('Y-m-d H:i:s', strtotime($_POST['invoice_due_date']));
                $invoice_details = $invoice_details_json_encode;

                $table_name = $wpdb->prefix . "service_crm_invoice_invoices";
                if (isset($_POST['new_invoice']) && $_POST['new_invoice'] == '1') {
                    // insert a new invoice
                    //$invoice_number = intval($_POST['invoice_number']);
                    if ($this->checkInvoiceNumber($invoice_number, $id)) {
                        $postVal = $_POST;
                        $postVal = json_encode($postVal);
                        $sessionSaved = $this->service_crm_invoice_set_session_val($postVal);
                        if (!$sessionSaved) {
                            $wpdb->show_errors();
                        } else {
                            wp_redirect(admin_url('admin.php') . '?page=invoices-page&company_id=' . $company_id . '&property_id=' . $property_id . '&invoice_id=' . $id . '&invoice_number=' . $invoice_number . '&redirect=true');
                            exit;
                        }
                    } else {
                        $wpdb->query($wpdb->prepare(
                        "
                            INSERT INTO $table_name
                            ( 
                                company_id,
                                property_id,
                                invoice_number,
                                invoice_date,
                                salesperson,
                                po_number,
                                requisitioner,
                                fob_point,
                                terms,
                                pay_status,
                                comments,
                                agreement_type,
                                invoice_type,
                                invoice_due_date,
                                invoice_details
                            )
                            VALUES
                            (
                                %d, 
                                %d,
                                %d,
                                %s,
                                %s, 
                                %s,
                                %s,
                                %s,
                                %s,
                                %s,
                                %s,
                                %s,
                                %s,
                                %s,
                                %s
                            )
                            ", $company_id, $property_id, $invoice_number, $invoice_date, $salesperson, $po_number, $requisitioner, $fob_point, $terms, $pay_status, $comments, $agreement_type, $invoice_type, $invoice_due_date, $invoice_details
                        ));
                        if ($wpdb->insert_id === false) {
                            $wpdb->show_errors();
                        } else {
                            add_action('admin_notices', 'my_db_success_notice');
                            wp_redirect(admin_url()); //$_SERVER['HTTP_REFERER'] );
                            exit();
                        }
                    }
                } else {
                    if ($this->checkInvoiceNumber($invoice_number, $id)) {
                        $postVal = $_POST;
                        $postVal = json_encode($postVal);
                        $sessionSaved = $this->service_crm_invoice_set_session_val($postVal);
                        if (!$sessionSaved) {
                            $wpdb->show_errors();
                        } else {
                            wp_redirect(admin_url('admin.php') . '?page=invoices-page&company_id=' . $company_id . '&property_id=' . $property_id . '&invoice_id=' . $id . '&invoice_number=' . $invoice_number . '&redirect=true');
                            exit;
                        }
                    }
                    $result = $wpdb->update(
                        $table_name, 
                            array(
                                'invoice_number' => $invoice_number,
                                'invoice_date' => $invoice_date,
                                'salesperson' => $salesperson,
                                'po_number' => $po_number,
                                'requisitioner' => $requisitioner,
                                'fob_point' => $fob_point,
                                'terms' => $terms,
                                'pay_status' => $pay_status,
                                'comments' => $comments,
                                'agreement_type' => $agreement_type,
                                'invoice_type' => $invoice_type,
                                'invoice_due_date' => $invoice_due_date,
                                'invoice_details' => $invoice_details
                            ), array('id' => $id), array(
                                '%d',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s',
                                '%s'
                            ), array('%d')
                    );
                    if ($result === false) {
                        // send a message that we failed;
                        echo "
                            <div class='notice notice-error'>
                                    Last Query: $wpdb->last_query.<br/>
                                    Update Failed:$wpdb->show_errors.<br/>
                                    Last Error: $wpdb->last_error.<br/>

                            </div>";
                        die();
                    } else {
                        wp_redirect(admin_url());
                        exit();
                    }
                }
            } else {
                die('$_POST is empty'); // this should not happen
            }
        } else {
            echo "<div class='notice notice-error'>You must be an admin to perform this function.</div>";
        }
    }

    /*
     * Dropdown for state - borrowed from online 
     * http://online-code-generator.com/usa-state-html-select-list-custom-formats.php
     */
    function StateDropdown($post = null, $type = 'abbrev') {
        $states = array(
            array('AK', 'Alaska'),
            array('AL', 'Alabama'),
            array('AR', 'Arkansas'),
            array('AZ', 'Arizona'),
            array('CA', 'California'),
            array('CO', 'Colorado'),
            array('CT', 'Connecticut'),
            array('DC', 'District of Columbia'),
            array('DE', 'Delaware'),
            array('FL', 'Florida'),
            array('GA', 'Georgia'),
            array('HI', 'Hawaii'),
            array('IA', 'Iowa'),
            array('ID', 'Idaho'),
            array('IL', 'Illinois'),
            array('IN', 'Indiana'),
            array('KS', 'Kansas'),
            array('KY', 'Kentucky'),
            array('LA', 'Louisiana'),
            array('MA', 'Massachusetts'),
            array('MD', 'Maryland'),
            array('ME', 'Maine'),
            array('MI', 'Michigan'),
            array('MN', 'Minnesota'),
            array('MO', 'Missouri'),
            array('MS', 'Mississippi'),
            array('MT', 'Montana'),
            array('NC', 'North Carolina'),
            array('ND', 'North Dakota'),
            array('NE', 'Nebraska'),
            array('NH', 'New Hampshire'),
            array('NJ', 'New Jersey'),
            array('NM', 'New Mexico'),
            array('NV', 'Nevada'),
            array('NY', 'New York'),
            array('OH', 'Ohio'),
            array('OK', 'Oklahoma'),
            array('OR', 'Oregon'),
            array('PA', 'Pennsylvania'),
            array('PR', 'Puerto Rico'),
            array('RI', 'Rhode Island'),
            array('SC', 'South Carolina'),
            array('SD', 'South Dakota'),
            array('TN', 'Tennessee'),
            array('TX', 'Texas'),
            array('UT', 'Utah'),
            array('VA', 'Virginia'),
            array('VT', 'Vermont'),
            array('WA', 'Washington'),
            array('WI', 'Wisconsin'),
            array('WV', 'West Virginia'),
            array('WY', 'Wyoming')
        );

        $options = '<option value=""></option>';

        foreach ($states as $state) {
            if ($type == 'abbrev') {
                $options .= '<option value="' . $state[0] . '" ' . $this->check_select($post, $state[0], false) . ' >' . $state[0] . '</option>' . "\n";
            } elseif ($type == 'name') {
                $options .= '<option value="' . $state[1] . '" ' . $this->check_select($post, $state[1], false) . ' >' . $state[1] . '</option>' . "\n";
            } elseif ($type == 'mixed') {
                $options .= '<option value="' . $state[0] . '" ' . $this->check_select($post, $state[0], false) . ' >' . $state[1] . '</option>' . "\n";
            }
        }

        echo $options;
    }

    /**
     * Check Select Element 
     *
     * @param string $i, POST value
     * @param string $m, input element's value
     * @param string $e, return=false, echo=true 
     * @return string 
     */
    function check_select($i, $m, $e = true) {
        if ($i != null) {
            if ($i == $m) {
                $var = ' selected="selected" ';
            } else {
                $var = '';
            }
        } else {
            $var = '';
        }
        if (!$e) {
            return $var;
        } else {
            echo $var;
        }
    }

    
    /*
     * Get a list of users with the "subscribe" role to associate with a company
     */
    function get_user_select($user_id = null, $return_blogusers = false, $return_user_name) {
        $blogusers = get_users(['role__in' => ['subscriber']]);

        $options = "<option value=''>Select a user</option>";
        if (!empty($blogusers)) {
            foreach ($blogusers as $user) {
                if ($return_user_name && $user_id == $user->id) {
                    return $user->display_name;
                    break;
                } else {
                    $options .= "<option value='" . $user->ID . "'" . $this->check_select($user_id, $user->ID, false) . ">" . $user->display_name . "</option>";
                }
            }
        }
        if ($return_blogusers) {
            return $blogusers;
        } else {
            return $options;
        }
    }

    /*
     * Get last invoice number to display on invoice form.  Used to assist in managing a unique invoice number.
     */
    public function service_crm_invoice_get_last_invoice_number() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'service_crm_invoice_invoices';
        $service_crm_invoice_last_invoice = $wpdb->get_results(
                "SELECT MAX( invoice_number ) as last_invoice_number FROM $table_name WHERE 1", "ARRAY_A"
        );
        if (count($service_crm_invoice_last_invoice) !== 0) {
            echo $service_crm_invoice_last_invoice[0]['last_invoice_number'];
        }
    }

    /*
     * Remove temporary invoice from temp table. Used in managind session values during instance of not unique invoice number.
     */
    function service_crm_invoice_unset_session_val($id) {
        global $wpdb;
        if (is_admin()) {
            if (!empty($id)) {
                $table_name = $wpdb->prefix . 'service_crm_invoice_session_temp';
                $select_service_crm_invoice_session_temp = $wpdb->delete(
                        "$table_name", array('id' => $id)
                );
            }
        }
    }

    /*
     * Add temporary invoice ro temp table. Used in managind session values during instance of not unique invoice number.
     */
    function service_crm_invoice_set_session_val($sessionVal) {
        global $wpdb;

        $session_save_table_name = $wpdb->prefix . 'service_crm_invoice_session_temp';
        $wpdb->query($wpdb->prepare(
        "
            INSERT INTO $session_save_table_name (
                savesession
            ) VALUES (
                %s
            )
        ", $sessionVal
        ));
        if ($wpdb->insert_id === false) {
            return false;
        } else {
            return true;
        }
    }

    /*
     * Get temp invoice from temp table.  Used in managind session values during instance of not unique invoice number.
     */
    function service_crm_invoice_get_session_val($company_id = null, $property_id = null, $invoice_number = null) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'service_crm_invoice_session_temp';
        $select_service_crm_invoice_session_temp = $wpdb->get_results(
        "
            SELECT id, savesession FROM $table_name WHERE 1
        "
        );
        if (!empty($select_service_crm_invoice_session_temp)) {
            $returnArray = array();
            foreach ($select_service_crm_invoice_session_temp as $sessionVal) {
                $postVal = json_decode($sessionVal->savesession, true);

                if ($postVal['company_id'] == $company_id &&
                        $postVal['property_id'] == $property_id &&
                        $postVal['invoice_number'] == $invoice_number) {
                    $returnArray['sessionId'] = $sessionVal->id;
                    $returnArray['postVal'] = $postVal;
                    //return $postVal;
                    return $returnArray;
                    break;
                }
            }
            return false; //if none is found.   Should not happen
        } else {
            return false;
        }
    }

    /*
     * Get Invoice data for List Invoice or Edit Invoice.
     */
    function service_crm_invoice_get_invoice_data($id = null, $property_id) {
        global $wpdb;

        if (!empty($id)) {
            $where = " WHERE id=$id";
        } elseif (!empty($property_id)) {
            $where = " WHERE property_id = $property_id";
        } else {
            $where = " WHERE 1 ";
        }
        $table_name = $wpdb->prefix . 'service_crm_invoice_invoices';
        $select_service_crm_invoice_invoices = $wpdb->get_results(
        "
            SELECT id, property_id, company_id, invoice_number, invoice_date, salesperson, po_number, requisitioner, fob_point, terms, pay_status, invoice_details, comments, invoice_type, agreement_type, invoice_due_date
            FROM $table_name
            $where
        "
        );
        return $select_service_crm_invoice_invoices;
    }

    /*
     * Get property data for List Property of Edit Property
     */
    function service_crm_invoice_get_property_data($property_id = null, $company_id = null) {
        global $wpdb;

        if (!empty($property_id)) {
            $where = " WHERE id=$property_id";
        } elseif (!empty($company_id)) {
            $where = " WHERE company_id=$company_id";
        } else {
            $where = " WHERE 1 ";
        }
        $table_name = $wpdb->prefix . 'service_crm_invoice_properties';
        $select_service_crm_invoice_properties = $wpdb->get_results(
        "
            SELECT id, company_id, name, address1, address2, address3, city, state, zip, country, phone1, phone2, note1, note2
            FROM $table_name
            $where
        "
        );
        return $select_service_crm_invoice_properties;
    }

    /*
     * Get Company data for List Company of Edit Company
     */
    function service_crm_invoice_get_company_data($id = null) {
        global $wpdb;

        if (!empty($id)) {
            $where = " WHERE id=$id";
        } else {
            $where = " WHERE 1 ";
        }
        $table_name = $wpdb->prefix . 'service_crm_invoice_company';
        $select_service_crm_invoice_company = $wpdb->get_results(
        "
            SELECT id, name, user_id, address1, address2, address3, city, state, zip, country, phone1, phone2, phone3, fax, note1, note2, url
            FROM $table_name 
            $where
        "
        );
        if ($select_service_crm_invoice_company === false) {
            echo $wpdb->show_errors();
        }
        return $select_service_crm_invoice_company;
    }

    /*
    function service_crm_invoice_company_dropdown($property_company_id) {

        $select_service_crm_invoice_company = $this->service_crm_invoice_get_company_data();

        $options = "<option value=''>Select a Company</option>";
        foreach ($select_service_crm_invoice_company as $company) {
            $options .= "<option value='" . $company->id . "'" . $this->check_select($property_company_id, $company->id, false) . ">";
            $options .= $company->name . '-' . $company->address1;
            $options .= "</option>";
        }

        return $options;
    }
    */
    
    /*
     * Used in list properties and list invoices
     */
    function service_crm_invoice_get_company_name($property_company_id) {
        $select_service_crm_invoice_company = $this->service_crm_invoice_get_company_data($property_company_id);
        foreach ($select_service_crm_invoice_company as $company) {
            $company_name = $company->name;
            break;
        }
        return $company_name;
    }
    
    /*
     * Used in list invoices
     */
    function service_crm_invoice_get_property_name($property_id) {
        $select_service_crm_invoice_properties = $this->service_crm_invoice_get_property_data($property_id);
        foreach ($select_service_crm_invoice_properties as $property) {
            $property_name = $property->name;
            break;
        }
        return $property_name;
    }
    
    
    /*
     * Get Settings for SCI system.
     */
    function service_crm_invoice_get_settings() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'service_crm_invoice_settings';
        $select_service_crm_invoice_settings = $wpdb->get_results(
        "
            SELECT id, logo_url, title_name, title_tag, address1, address2, city, state, zip, phone1, phone2, fax
            FROM $table_name
            LIMIT 1
        "
        );
        if (!empty($select_service_crm_invoice_settings)) {
            return $select_service_crm_invoice_settings;
        } else {
            return 'Database Error';
        }
    }

}