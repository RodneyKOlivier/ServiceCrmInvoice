(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	$(document).on('click', '#show_hide_companies_button', function() {
		$('#show_hide_companies').toggle();
		if( $('#show_hide_companies').is(':hidden')){
			$('#show_hide_companies_button').val("Show Companies Table");
		} else {
			$('#show_hide_companies_button').val("Hide Companies Table");
		}
	});
	$(document).on('click', '#show_hide_users_button', function() {
		$('#show_hide_users').toggle(); 
		if( $('#show_hide_users').is(':hidden')){
			$('#show_hide_users_button').val("Show User Table");
		} else {
			$('#show_hide_users_button').val("Hide User Table");
		}
	});
	$(document).on('click','.service_crm_invoice_company_id_select', function() {
		var dataVal = $(this).attr('data');
		var dataVal2 = $(this).attr('data_company_name');
		$('#service_crm_invoice_properties_company_id').val(function(){
			return dataVal;
		});
		$('#service_crm_invoice_property_company_name').val( function(){
			return dataVal2;
		} );
	});
	$(document).on('click', '#service_crm_invoice_user_id_button', function() {
		var dataVal = $(this).attr('data');
		var nameVal = $(this).attr('nameVal');
		$('#service_crm_invoice_user_id').val(function(){
			return dataVal;
		});
		$('#service_crm_invoice_user_name').val( function(){
			return nameVal;
		});
	});
	$(document).on('click', '#service_crm_invoice_invoice_add_new', function() {
		$('#service_crm_invoice_invoice_add_new_invoice').val('1');
		$('#service_crm_invoice_invoices_list_form').submit();
	});
	$(document).on('click', '.service_crm_invoice_invoice_list_submit', function() {
		//var company_idVal = $(this).attr('company_id');
		//var property_idVal = $(this).attr('property_id');
		var invoice_idVal = $(this).attr('invoice_id');
		//$('#service_crm_invoice_company_id').val( function(){
		//	return company_idVal;
		//});
		//$('#service_crm_invoice_property_id').val( function(){
		//	return property_idVal;
		//});
		$('#service_crm_invoice_invoice_id').val( function(){
			return invoice_idVal;
		});
		$('#service_crm_invoice_invoices_list_form').submit();
	});
	$(document).on('click', '.service_crm_invoice_company_list_submit', function() {
		var dataVal  = $(this).attr('data'); 
		$('#service_crm_invoice_company_id').val( function(){
			return dataVal; 
			//$('#service_crm_invoice_company_list_submit').attr('data');
		});
		$('#service_crm_invoice_company_list_form').submit();
	});
	
	$(document).on('click', '.service_crm_invoice_property_list_submit', function() { 
		var dataVal = $(this).attr('data');
		$('#service_crm_invoice_property_id').val( function(){
			return dataVal;
		});
		$('#service_crm_invoice_property_list_form').submit();
	});
	
	$(function(){
         // Let's set up some variables for the image upload and removing the image     
         var frame,
             imgUploadButton = $( '#upload_login_logo_button' ),    
             imgContainer = $( '#upload_logo_preview' ),
             imgIdInput = $( '#login_logo_id' ),
			 imgLogoUrl = $('#logo_url' ),
             imgPreview = $('#upload_logo_preview'),        
             imgDelButton = $('#wp_cbf-delete_logo_button'),
             // Color Pickers Inputs
             colorPickerInputs = $( '.wp-cbf-color-picker' );

         // WordPress specific plugins - color picker and image upload
         $( '.wp-cbf-color-picker' ).wpColorPicker();

        // wp.media add Image
         imgUploadButton.on( 'click', function( event ){

            event.preventDefault();

            // If the media frame already exists, reopen it.
            if ( frame ) {
              frame.open();
              return;
            }

            // Create a new media frame
            frame = wp.media({
              title: 'Select or Upload Media for your Login Logo',
              button: {
                text: 'Use as my Login page Logo'
              },
              multiple: false  // Set to true to allow multiple files to be selected
            });
            // When an image is selected in the media frame...
            frame.on( 'select', function() {

              // Get media attachment details from the frame state
				var attachment = frame.state().get('selection').first().toJSON();                

				// Send the attachment URL to our custom image input field.
				imgPreview.find( 'img' ).attr( 'src', attachment.sizes.thumbnail.url );
				//alert();
				imgLogoUrl.val(attachment.sizes.thumbnail.url);
				// Send the attachment id to our hidden input
				imgIdInput.val( attachment.id );

				// Unhide the remove image link
				imgPreview.removeClass( 'hidden' );
            });

            // Finally, open the modal on click
            frame.open();
        });

        // Erase image url and age preview
        imgDelButton.on('click', function(e){
            e.preventDefault();
            imgIdInput.val('');
            imgPreview.find( 'img' ).attr( 'src', '' );
            imgPreview.addClass('hidden');
        });
		$('document').ready(function() {
			$('.phone').mask('(999) 999-9999');
			$('.datepicker').mask('99/99/9999');
			
			$(".numspin").val( function(){
				var thisVal = $(this).val();
				return formatCurrency(thisVal);
			});
			//$(".intspin").mask("9?999999999");
		});
		
		 function formatCurrency(total) {
			var neg = false;
			if(total < 0) {
				neg = true;
				total = Math.abs(total);
			}/*(neg ? "-$" : '$') +*/
			return  (neg ? "-" : '') + parseFloat(total, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString();
		}
		$( function() {
			$( '.datepicker' ).datepicker();
		} );
		
		//$('.agreementType').checkboxradio();
		$('.intspin').spinner({
			culture: "en",
			numberFormat: "n",
			min: 1,
			max: 999999999,
			step: 1
		});
		$('.numspin').spinner({
			culture: "en",
			min:-999999999,
			max:999999999,
			step: 1,
			numberFormat: "n"
		});
		$('.ui-spinner-button').on('click', function(){
		   $(this).siblings('input').change();
		});
		//$( ".numspin" ).on( "spinchange", function( event, ui ) {} );
		
		$(document).on('click','.print-button', function() {
			window.print();  
			return false; // why false?
		});
		
		/* invoice functions*/
		
		// add row functions
		
		function set_current_row(i){
			$('#current_row').val( function() {
				return i;
			});
		}
		
		$(document).on('click','.remove_row', function() {
			var delete_row = $(this).attr('data');
			$('#row_'+delete_row).remove();
			var array_count = parseInt($('#array_count').val());
			array_count--;
			$('#array_count').val( function() {
				return array_count;
			});
			setValues();
			/* set_subtotal();
			set_sales_tax();
			set_ship_handle();
			set_grand_total(); */
		});
		
		$(document).on('click', '#service_crm_invoice_add_row', function(){
			//alert('In Add Row');
			var array_count = parseInt($('#array_count').val());
			array_count++;
			$('#array_count').val( function() {
				return array_count;
			});
			
			var row =  parseInt( $('#invoiceNewInnerTable tr:last').attr('id').replace(/[^0-9\.]/g, ''), 10 ) + 1;
			
			//$('.remove_row').on('hover')
			/* var quantity_id = "quantity_"+array_count;
			var quantity_name = "quantity["+array_count+"]";
			
			var description_id = "description_"+array_count;
			var description_name = "description["+array_count+"]";
			
			var unitprice_id = "unitprice_"+array_count;
			var unitprice_name = "unitprice["+array_count+"]";
			
			var totalprice_id = "totalprice_"+array_count;
			var totalprice_name = "totalprice["+array_count+"]"; */
			
			var quantity_id = "quantity_"+row;
			var quantity_name = "quantity["+row+"]";
			
			var description_id = "description_"+row;
			var description_name = "description["+row+"]";
			
			var unitprice_id = "unitprice_"+row;
			var unitprice_name = "unitprice["+row+"]";
			
			var totalprice_id = "totalprice_"+row;
			var totalprice_name = "totalprice["+row+"]";
			
			//var current_row_html = "document.getElementById('current_row').value='"+array_count+"'";
			var current_row_html = "document.getElementById('current_row').value='"+row+"'";
			//var row_text  = '<tr id="row_'+array_count+'">';
			var row_text  = '<tr id="row_'+row+'">';
				row_text += '<td class="bodyBodyAdd">';
				row_text += '<input class="quantityValue textAlignRight intspin" onfocus="'+current_row_html+'" id="'+quantity_id+'" tabindex="'+((row*11)+1)+'" type="text" pattern="[0-9]{1,999999999}" name="'+quantity_name+'" size="15" minlength="1" maxlength="9" value="0" placeholder="Quantity" required min="1" max="999999999" />';
				row_text += '</td>';
				row_text += '<td colspan="3"  class="bodyBodyAdd">';
				row_text += '<textarea onfocus="'+current_row_html+'" id="'+description_id+'" tabindex="'+((row*12)+1)+'" name="'+description_name+'" maxlength="512" placeholder="Description" rows="4" cols="59" wrap="soft" required ></textarea>';
				row_text += '</td>';
				row_text += '<td class="bodyBodyAdd">';
				row_text += '<input class="unitPrice textAlignRight numspin" onfocus="'+current_row_html+'" id="'+unitprice_id+'" tabindex="'+((row*13)+1)+'" type="text" name="'+unitprice_name+'" pattern="^[+-]?[0-9].[0-9]{0,2}" value="0.00" placeholder="0.00" required />';
				row_text += '</td>';
				row_text += '<td class="bodyBodyAdd bodyBodyRight textAlignRight">';
				//row_text += '<input type="button" class="remove_row" data='+array_count+' value="X" title="Remove this row." />';
				row_text += '<input type="button" class="remove_row ui-button ui-widget ui-corner-all" data='+row+' tabindex="-1" value="X" title="Remove this row." />';
				row_text += '<input class="totalPrice textAlignRight" onfocus="'+current_row_html+'" id="'+totalprice_id+'" tabindex="'+((row*14)+2)+'" type="text" name="'+totalprice_name+'"  size="14" maxlength="25" value="0.00" required />';
				row_text += '</td>';
				row_text += '</tr>';
			
			$('#invoiceNewInnerTable tr:last').after( row_text );
			$('.intspin').spinner({
				culture: "en",
				numberFormat: "n",
				min: 1,
				max: 999999999,
				step: 1
			});
			$('.numspin').spinner({
				culture: "en",
				min:-999999999,
				max:999999999,
				step: 1,
				numberFormat: "n"
			});
			$('.ui-spinner-button').on('click', function(){
				$(this).siblings('input').change();
			});
			//RefreshSomeEventListener();
			/* $('.quantityValue').on('change', '.quantityValue', function(){
				var current_row = parseInt($('#current_row').val());
				set_total_price(current_row);
				setValues();
			});*/
			/*$('.unitPrice').on('change', '.unitPrice', function() {*/
			/* $(document).on('change', '.unitPrice', function() { 
				var current_row = parseInt($('#current_row').val());
				set_total_price(current_row);
				setValues();
			}) */
		});
		
		
		 function set_total_price(i){
			var quantity = parseInt($('#quantity_'+i).val());
			var unit_price = parseFloat($('#unitprice_'+i).val(),10);
			
			if (isNaN( quantity ) ){ quantity = 0;}
			if (isNaN( unit_price ) ){ unit_price = 0;}
			
			var total_value = quantity * unit_price;
			
			$('#totalprice_'+i).val( function(){
				return parseFloat(total_value,10).toFixed(2);
			});
			$('#unitprice_'+i).val( function() {
				return formatCurrency(unit_price);
				//return parseFloat(unit_price,10).toFixed(2);
			});
		} 
	
	
		 function set_grand_total(){
			var subtotal = parseFloat($('#subtotal').val(),10);
			if( isNaN(subtotal) ){subtotal = 0.00;}
			var sales_tax = parseFloat($('#sales_tax').val(),10);
			if( isNaN(sales_tax) ){ sales_tax = 0.00;}
			var ship_handle = parseFloat($('#ship_handle').val(),10);
			if( isNaN(ship_handle) ){ ship_handle = 0.00; }
			var valToConvert = parseFloat( subtotal + sales_tax + ship_handle, 10).toFixed(2);
			$('#grand_total').val( function() {
				return valToConvert;
			});
			$('#grandTotalNum').text( function() {
				return '$'+valToConvert;
			});
			
			$.get( 'http://localhost/wp48/wp-content/plugins/service-crm-invoice/includes/NumbersIndex.php?grand_total='+valToConvert, 	function( data ) {
				var strToConvert = data;
				strToConvert = strToConvert.replace(/\b[a-z]/g, function(letter) {/*.toLowerCase()*/
					return letter.toUpperCase();
				});
				$('#grandTotalWords').text( strToConvert );
			});
			
			// ajax call to update. grandTotalWords
		} 
		function set_subtotal(){
			//var total_rows  = parseInt($('#array_count').val()  ,10);
			//total_rows++;
			//var addon = (parseFloat(receivedamt)+parseFloat(addon)).toFixed(2);
			var subtotal = 0.00;
			$('.totalPrice').each( function(){
				subtotal += parseFloat($(this).val());
			});
			
			$('#subtotal').val( parseFloat(subtotal,10).toFixed(2) );
		}
		
		 function set_sales_tax(){
			$('#sales_tax').val( function(){
				var sales_taxVal = parseFloat($('#sales_tax').val(),10).toFixed(2);
				if ( isNaN(sales_taxVal) ){
					return '0.00';
				} else {
					return sales_taxVal;
				}
			});
		} 
		 function set_ship_handle(){
			$('#ship_handle').val( function(){
				var ship_handleVal = parseFloat($('#ship_handle').val(),10).toFixed(2);

				if ( isNaN(ship_handleVal) ){
					return '0.00';
				} else {
					return ship_handleVal;
				}
			});
		} 
		 $(document).on('click', '.grandTotals', function() {
			setValues();
		}); 
		
		/* function RefreshSomeEventListener() {
			// Remove handler from existing elements
			$(".quantityValue").off(); 

			// Re-add event handler for all matching elements
			$("body").on("click",'.quantityValue', function() {
				// Handle event.
				var current_row = parseInt($('#current_row').val());
				console.log(current_row);
				set_total_price(current_row);
				
				setValues();
			});
		} */
		$('#invoiceNewInnerTable').on("change",'.quantityValue', function() {
				// Handle event.
				var current_row = parseInt($('#current_row').val());
				console.log(current_row);
				set_total_price(current_row);
				
				setValues();
			});
		/* $(document).on('change', '.quantityValue', function(){ */
		/* $('body').on('change', '.quantityValue', function(){
			var current_row = parseInt($('#current_row').val());
			console.log(current_row);
			set_total_price(current_row);
			
			setValues();
			
		}); */
		$(document).on('change', '.unitPrice', function() { 
		/* $('body').on('change', '.unitPrice', function() { */
			var current_row = parseInt($('#current_row').val());
	
			set_total_price(current_row);
			
			setValues();
			
		});
		function setValues(){
			set_subtotal();
			set_sales_tax();
			set_ship_handle();
			set_grand_total();
		}
		 $(document).on('change', '.totalPrice', function() {
			var current_row = parseInt($('#current_row').val());
			set_total_price(current_row);

			setValues();

		});
		
		$(document).on('click', '.invoiceType', function() {
			$(".invoiceType").attr("checked", false); //uncheck all checkboxes
			$(this).attr("checked", true); 
		});
		
    }); // End of DOM Ready
	$(document).ready( function(){
		$('#service_crm_invoice_customer_datatable').dataTable();
		$('#service_crm_invoice_invoices_datatable').dataTable();
		$('#service_crm_invoice_property_datatable').dataTable();
		$('#service_crm_invoice_invoice_datatable').dataTable();
		$('#service_crm_invoice_companies_properties').dataTable();
		$('#blog_users_table').dataTable({
			/* "columnDefs": [
				{ "orderable": false, "targets": 0 }
				]
			} */ 
			"columns": [
			{ "orderable": false },
			null,
			null
		  ]
		});
		// Call our function to setup initial listening
		//RefreshSomeEventListener();
	});
})( jQuery );
