<?php
//var_dump($company_user_name);
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

	<div class='wrap'>
		<h2><?php echo $page_title; ?></h2>
		<?php 
		  if( $new_company == 'false') {
			echo '<a class="ui-button ui-widget ui-corner-all" href="'.admin_url('admin.php').'?page=company-page&company_add_new=true'.'" > Add New </a>'; 
			}
		?>
		<br/>
		<form id="service_crm_company_form_id" action="<?php echo admin_url( 'admin.php' ); ?>" method="post" >
			<input type="hidden" name="action" value="<?php echo $page_action; ?>" />
			<input type="hidden" name="company_add_new" value="<?php echo $new_company; ?>" />
			<input type="hidden" name="id" value="<?php echo $company_id; ?>" />
			<input type="hidden" id="service_crm_invoice_user_id" name="user_id" value="<?php echo $company_user_id; ?>" />
			
			<?php 
				$blogusers = $this->get_user_select($company_user_id, true, false); 
				?>
				<input type="button" class="ui-button ui-widget ui-corner-all" id="show_hide_users_button" value="Hide User Table" />
				<p>Select the User from the following table.<p>
				<div id="show_hide_users">
				<table id="blog_users_table" cellspacing="0" cellpadding="0" border="0" >
					<thead>
						<th>&nbsp;</th>
						<th>User ID</th>
						<th>User Name</th>
					</thead>
					<tbody>
						<?php
							foreach ($blogusers as $user){
							?>
							<tr>
								<td><input type="button" class="ui-button ui-widget ui-corner-all" id="service_crm_invoice_user_id_button" data="<?php echo $user->ID; ?>" nameVal="<?php echo $user->display_name; ?>" value="Select User" /></td>
								<td><?php echo $user->ID; ?></td>
								<td><?php echo $user->display_name; ?></td>
							</tr>
							<?php
							}
						?>
					</tbody>
				</table>
				</div>
			<?php /* <select id="user_id" name="user_id" required>
				<?php echo $this->get_user_select($company_user_id); ?>
			</select> */ ?>
			<label for="service_crm_invoice_user_name"> Assign User to this Company</label>
			<input type="text" id="service_crm_invoice_user_name" disabled name="user_name" value="<?php echo $company_user_name; ?>" />
			<br />
			<br/>
			<label class="scc_form_label" for="company_name">Company Name </label><input id="company_name" type="text" name="name" required placeholder="Company name" size="50" value="<?php echo $company_name; ?>" />
			<br />
			<label for="company_address1">Address1 </label><input id="company_address1" type="text" name="address1" required placeholder="Company address" size="50" value="<?php echo $company_address1; ?>" />
			<br />
			<label for="company_address2">Address2 </label><input id="company_address2" type="text" name="address2" placeholder="Company address" size="50" value="<?php echo $company_address2; ?>" />
			<br />
			<label for="company_address3">Address3 </label><input id="company_address3" type="text" name="address3" placeholder="Company address" size="50" value="<?php echo $company_address3; ?>" />
			<br />
			<label for="company_city">City </label><input id="company_city" type="text" name="city" required placeholder="Company city" size="50" value="<?php echo $company_city; ?>" />
			<br />
			<label for="company_state">State </label>
			<select id="company_state" name="state"><?php echo $this->StateDropdown("$company_state", 'abbrev'); ?></select>
			<br />
			<label for="company_zip">Zip </label><input id="company_zip" type="text" name="zip" required placeholder="Company zip" size="10" value="<?php echo $company_zip; ?>" />
			<br />
			<label for="company_country">Country </label><input id="company_country" type="text" name="country" required placeholder="Company County" size="50" value="<?php echo $company_country; ?>" />
			<br />
			<label for="company_phone1">Phone 1 </label><input id="company_phone1" class="phone"  type="tel" name="phone1" required placeholder="Company phone" size="14" value="<?php echo $company_phone1; ?>" />
			<br />
			<label for="company_phone2">Phone 2 </label><input id="company_phone2" class="phone" type="tel" name="phone2" placeholder="Company phone" size="14" value="<?php echo $company_phone2; ?>" />
			<br />
			<label for="company_phone3">Phone 3 </label><input id="company_phone3" class="phone" type="tel" name="phone3" placeholder="Company phone" size="14" value="<?php echo $company_phone3; ?>" />
			<br />
			<label for="company_fax">Fax </label><input id="company_fax" class="phone" type="tel" name="fax" placeholder="Company fax" size="14" value="<?php echo $company_fax; ?>" />
			<br />
			<label for="company_url">URL </label><input id="company_url" type="url" name="url" placeholder="Company url" size="50" value="<?php echo $company_url; ?>" />
			<br />
			<label for="company_ note1">Note 1 </label><textarea id="company_note1" name="note1" cols="50" rows="4" maxlength="255"><?php echo $company_note1; ?></textarea>
			<br />
			<label for="company_ note2">Note 2 </label><textarea id="company_note2" name="note2" cols="50" rows="4" maxlength="255"><?php echo $company_note2; ?></textarea>
			<input class="ui-button ui-widget ui-corner-all" type="Submit" />
		</form>
	</div>
	
