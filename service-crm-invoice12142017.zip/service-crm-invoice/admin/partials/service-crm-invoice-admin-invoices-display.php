<?php
/*  echo '<pre>';
var_dump($quantity_array);
echo '</pre>'; */
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/admin/partials
 */
 	
	if( !empty($select_service_crm_invoice_settings) ){
		foreach( $select_service_crm_invoice_settings as $setting){
			$setting_logo_url = $setting->logo_url;
			$setting_title_name = $setting->title_name;
			$setting_title_tag = $setting->title_tag;
			$setting_address1 = $setting->address1;
			$setting_address2 = $setting->address2;
			$setting_city = $setting->city;
			$setting_state = $setting->state;
			$setting_zip = $setting->zip;
			$setting_phone1 = $setting->phone1;
			$setting_phone2 = $setting->phone2;
			$setting_fax = $setting->fax;
		}
	} else {
		$setting_logo_url = '';
		$setting_title_name = '';
		$setting_title_tag = '';
		$setting_address1 = '';
		$setting_address2 = '';
		$setting_city = '';
		$setting_state = '';
		$setting_zip = '';
		$setting_phone1 = '';
		$setting_phone2 = '';
		$setting_fax = '';
	}
	if(!empty($property_array)){
		foreach($property_array as $property){
			$property_name = $property->name;
			$property_address1= $property->address1;
			$property_address2= $property->address2;
			$property_city = $property->city;
			$property_state = $property->state;
			$property_zip = $property->zip;
			$property_phone1 = $property->phone1;
			$property_phone2 = $property->phone2;
		}
	}else{
		$property_name = '';
		$property_address1 = '';
		$property_address2 = '';
		$property_city = '';
		$property_state = '';
		$property_zip = '';
		$property_phone1 = '';
		$property_phone2 = '';
	}
	
	if(!empty($company_array)){
		foreach ($company_array as $company){
			$company_name = $company->name;
			$company_address1 = $company->address1;
			$company_address2 = $company->address2;
			$company_address3 = $company->address3;
			$company_city = $company->city;
			$company_state = $company->state;
			$company_zip = $company->zip;
			$company_country = $company->country;
			$company_phone1 = $company->phone1;
			$company_phone2 = $company->phone2;
			$company_phone3 = $company->phone3;
			$company_fax = $company->fax;
		}
	} else {
		$company_name = '';
		$company_address1 = '';
		$company_address2 = '';
		$company_address3 = '';
		$company_city = '';
		$company_state = '';
		$company_zip = '';
		$company_country = '';
		$company_phone1 = '';
		$company_phone2 = '';
		$company_phone3 = '';
		$company_fax = '';
	}
	
	// setup company info values,
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class='wrap'>
<h2 class='wp-heading-inline'>
<?php echo $page_title; ?>
</h2>
<?php 
	if($new_invoice === false){
		echo "<a class='ui-button ui-widget ui-corner-all' href='".admin_url('admin.php')."?page=invoices-page&invoice_add_new=true' >Add New</a>";
	} 
?>
	<form method="post" action="<?php echo admin_url( 'admin.php' ); ?>" > <!-- .'?page=sub-page5' -->
		<table id="invoiceNewWrapper" cellspacing="0" cellpadding="0" border="0" >
			<thead>
				<tr>
					<th colspan='2'>
						<h2>Invoice Form for Company: <STRONG><?php echo $company_name; ?></STRONG> for Property: <STRONG><?php echo$property_name;?></STRONG>
						</h2>
					</th>
				</tr>
				<tr>
					<td>
						<div class="display_block logo_wrap">
							<?php if( !empty($setting_logo_url) ){
								//html: <img src="smiley.gif" alt="Smiley face" height="42" width="42">
								//wordpress: get_image_tag( $id, $alt, $title, $align, $size ); // all params are required
								echo "<image src='$setting_logo_url' alt='logo' height='103' width='84'>";
							} else {
								echo '&nbsp';
							}
							?>
						</div>
						<div class="display_block">
							<?php
								echo '<strong>'.$setting_title_name.'</strong><br/>';
								echo $setting_address1.'<br/>';
								if(!empty($setting_address2)) {echo $setting_address2.'<br/>';}
								echo $setting_city.', '.$setting_state.' '.$setting_zip.'<br/>';
								echo $setting_phone1.'<br/>';
								if(!empty($setting_phone2)) {echo $setting_phone2.'<br/>';}
								if(!empty($setting_fax)) {echo $setting_fax.'<br/>';} 
							?>
						</div>
						<div class="display_block">
							<?php 
								echo '<strong>'.$company_name.'</strong></br>';
								echo $company_address1.'<br/>';
								if (!empty($company_address2)){echo $company_address2.'<br/>';}
								if (!empty($company_address3)){echo $company_address3.'<br/>';}
								echo $company_city.',&nbsp;'.$company_state.'&nbsp;'.$company_zip.'&nbsp;'.$company_country.'<br/>';
								echo $company_phone1.'<br/>';
								if (!empty($company_phone2)) {echo $company_phone2.'<br/>';}
								if (!empty($company_phone3)) {echo $company_phone3.'<br/>';}
								if (!empty($company_fax)) {echo $company_fax.'<br/>';}
							?>
						</div>
						<div class="display_block">
							<?php 
								echo '<strong>'.$property_name.'</strong><br/>';
								echo $property_address1.'<br/>';
								if(!empty($property_address2)){echo $property_address2.'<br/>';}
								echo $property_city.',', $property_state.' '.$property_zip.'<br/>';
								echo $property_phone1.'<br/>';
								echo $property_phone2.'<br/>';
							?>
						</div>
						
					</td>
					<td class="textAlignRight">
						
					</td>
				</tr>
				<tr>
					<td>
						<div class="display_block logo_wrap">
						<!-- left empty intentionally -->
						&nbsp;
						<!-- <img src="" width="96px"> -->
						</div>
						<div class="display_block">
							&nbsp;
						</div>
						<div class="display_block">
							&nbsp;
						</div>
						<div class="display_block textAlignRight">
							<strong>INVOICE</br></strong>
							<input id="invoice_number" tabindex="1"	class="textAlignRight" type="text" name="invoice_number" size="9" maxlength="9" value="<?php echo$invoice_number; ?>" placeholder="Invoice Number" required />
							<br />
							<input id="invoice_date" tabindex="2" class="datepicker textAlignRight" type="text" size="10" name="invoice_date" value="<?php if(!empty($invoice_date)){echo date('m/d/Y', strtotime($invoice_date));} ?>" 
							placeholder="mm/dd/yyyy" required />
							<br/>
							<!-- payment statue -->
							<strong>Payment Status:</strong><br/>
							<?php $pay_status_value = array('unpaid','pastdue','paid');?>
							<select id="service_crm_invoice_pay_status" tabindex="3" name="pay_status" type="text" >
								<?php
								foreach ($pay_status_value as $status){
									echo "<option value='$status'".$this->check_select($status,$pay_status,false).">".$status."</option>";
								}
								?>
							</select>
						</div>
					</td>
					<td class="textAlignTop" >
						Last Invoice Number<br/>
						<?php echo $this->service_crm_invoice_get_last_invoice_number(); ?>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<h3>COMMENTS OR SPECIAL INSTRUCTIONS:</h3>
						<textarea id="comments" tabindex="4" name="comments" rows="2" cols="141" wrap="soft"><?php echo $comments; ?></textarea>
					</td>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>
						<input id="array_count" type="hidden" value="0" />
						<input id="current_row" type="hidden" value="0" />
						
						<input type="hidden" name='id' value="<?php echo $invoice_id;?>" />
						<input type="hidden" name="action" value="<?php echo $page_action; ?>" />
						<input type="hidden" name="property_id" value="<?php echo $property_id; ?>"/>
						<input type="hidden" name="company_id" value="<?php echo $company_id; ?>"/>
						<input type="hidden" name="new_invoice" value="<?php echo $new_invoice; ?>" />
						
						<br/>
						<table id="invoiceNewInnerTable" cellspacing="0" cellpadding="2" border="0" >
						<thead>
							<tr>
								<th width="20%" class="blockHeader">SALES PERSON</th>
								<th width="15%" class="blockHeader">P.O. NUMBER</th>
								<th width="15%" class="blockHeader">REQUISITIONER</th>
								<th width="15%" class="blockHeader">SHIPPED VIA</th>
								<th width="15%" class="blockHeader">F.O.B. POINT</th>
								<th width="20%" class="blockHeader blockHeaderRight">TERMS</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
								<td colspan="4">&nbsp;</td>
								<td class="textAlignRight">SUBTOTAL</td>
								<td class="blockBody blockBodyRight">
									<input class="grandTotals textAlignRight" id="subtotal" tabindex="100" name="subtotal" type="text"  value="<?php echo $subtotal; ?>" placeholder="0.00" />
								</td>
							</tr>
								<td colspan="4">&nbsp;</td>
								<td class="textAlignRight">SALESTAX</td>
								<td class="blockBody blockBodyRight">
									<input class="grandTotals textAlignRight"id="sales_tax" tabindex="101" name="sales_tax" type="text"  value="<?php echo $sales_tax; ?>" placeholder="0.00" />
								</td>
							<tr>
								<td colspan="4">&nbsp;</td>
								<td class="textAlignRight">SHIPPING & HANDLING</td>
								<td class="blockBody blockBodyRight">
									<input class="grandTotals textAlignRight" id="ship_handle" tabindex="102" name="ship_handle" type="text" value="<?php echo $ship_handle; ?>" placeholder="0.00" />
								</td>
							</tr>
							<tr>
								<td colspan="4">&nbsp;</td>
								<td class="textAlignRight">GRAND TOTAL</td>
								<td class="blockBody blockBodyRight">
									<input class="grandTotals textAlignRight" id="grand_total" tabindex="103" name="grand_total" type="text" value="<?php echo $grand_total; ?>" placeholder="0.00" />
								</td>
							</tr>
							<tr>
								<td colspan='6'>
									<p>All Material is guaranteed to be as specified, and the above work was performed in accordance with the drawings and specifications provided for the above work and was completed in a substanial workmanlike manner for the aggreed sum of: <span class="underline" id="grandTotalWords"><?php echo ucwords($numWordsGrandTotal);?></span>&nbsp;<span class="underline" id="grandTotalNum">($<?php echo $grand_total; ?>)</span>.
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="5">
									<p> This is a <label class='invoiceType ui-button ui-widget ui-corner-all' for="invoiceTypePartial"><input id="invoiceTypePartial" type="radio" name="invoice_type" <?php if($invoice_type == 'partial'){ echo 'checked';} ?> value="partial" required /> Partial </label>&nbsp;
									<label class='invoiceType ui-button ui-widget ui-corner-all' for="invoiceTypeFull">
									<input  id="invoiceTypeFull" type="radio" name="invoice_type" <?php if($invoice_type == 'full'){echo 'checked';} ?> value="full" required />Full </label>invoice due and payable by: <input class="datepicker textAlignRight" type="text" name="invoice_due_date" value="<?php if(!empty($invoice_due_date)){echo date('m/d/Y', strtotime($invoice_due_date));} ?>" placeholder="mm/dd/yyyy" required />
									<br/> 
									in accordance with our <label class='agreementType ui-button ui-widget ui-corner-all' for='agreementTypeAgreement'><input id="agreementTypeAgreement"  type="radio" name="agreement_type" <?php if($agreement_type == 'aggreement'){echo 'checked';} ?> value="aggreement" required /> Agreement </label>&nbsp;<label class='agreementType ui-button ui-widget ui-corner-all'  for='agreementTypeProposal'><input id="agreementTypeProposal"  type="radio" name="agreement_type" <?php if($agreement_type == 'proposal'){ echo 'checked';} ?> value="proposal" required /> Proposal </label>
									Respectfull Submitted: <span class="signature">William E. Oleen</span>
									</p>
								</td>
								<td class="alignBottom textAlignRight">
									<input class="ui-button ui-widget ui-corner-all" tabindex="104" type="submit" value="Save" />
								</td>
							</tr>
						</tfoot>
						<tbody>
							<tr>
								<td class="blockBody">
									<input id="salesperson" tabindex="5" type="text" name="salesperson" value="<?php echo $salesperson; ?>" size="15" maxlength="24" placeholder="Salesperson" />
								</td>
								<td class="blockBody">
									<input id="po_number" tabindex="6" type="text" name="po_number" value="<?php echo $po_number; ?>" size="15" maxlength="24" placeholder="P O Number" />
								</td>
								<td class="blockBody">
									<input id="requisitioner" tabindex="7" type="text" name="requisitioner" size="15" maxlength="99" value="<?php echo $property_name; ?>" required />
								</td>
								<td class="blockBody">
									<input id="shipped_via" tabindex="8" type="text" name="shipped_vai" size="15" maxlength="24" value="<?php echo $ship_vai; ?>" placeholder="Shipped Via" />
								</td>
								<td class="blockBody">
									<input id="fob_point" tabindex="9" type="text" name="fob_point" size="15" maxlength="24" value="<?php echo $fob_point; ?>" placeholder="F.O.B. point" />
								</td>
								<td class="blockBody blockBodyRight">
									<input id="terms" tabindex="10" type="text" name="terms" size="15" maxlength="24"  value="<?php echo $terms; ?>" placeholder="Terms" />
								</td>
							</tr>
							<tr>
								<td colspan="6" class="textAlignRight">
									<input id="service_crm_invoice_add_row" class="ui-button ui-widget ui-corner-all" tabindex="-1" type="button" value="Add Row" />
								</td>
							</tr>
							<tr>
								<th class="bodyHeader">QUANTITY</th>
								<th colspan="3" class="bodyHeader">DESCRIPTION OF WORK PERFORMED/SUPPLIES</th>
								<th class="bodyHeader">UNIT PRICE</th>
								<th class="bodyHeader bodyHeaderRight">TOTAL</th>
							</tr>

							<!-- repeating zone -->
							<?php for( $x = 0; $x < count($quantity_array); $x++){

								$row = $x +1;
								echo '<tr id="row_'.$row.'">';
								echo '<td class="bodyBody">';
								?>
									<input class="quantityValue textAlignRight intspin" onfocus="document.getElementById('current_row').value='<?php echo $row; ?>';"  id="quantity_<?php echo $row; ?>" tabindex="<?php echo ($row*11)+$x ; ?>" type="text" pattern="[0-9]{1,999999999}" name="quantity[<?php echo $x; ?>]" size="15" minlength="1" maxlength="9" value="<?php echo $quantity_array[$x]; ?>" placeholder="Quantity" required max="999999999" />
								<?php
								echo '</td>';
								echo '<td colspan="3" class="bodyBody">';
								?>
									<textarea onfocus="document.getElementById('current_row').value='<?php echo $row; ?>';" id="description_<?php echo $row; ?>" tabindex="<?php echo ($row*12)+$x; ?>" name="description[<?php echo $x; ?>]" maxlength="512" placeholder="Description" rows="4" cols="59" wrap="soft" required ><?php echo $description_array[$x]; ?></textarea>
								<?php
								echo '</td>';
								?>
								<td class="bodyBody">
									<input lang="en" class="unitPrice textAlignRight numspin" onfocus="document.getElementById('current_row').value='<?php echo $row; ?>';" id="unitprice_<?php echo $row; ?>" tabindex="<?php echo ($row*13)+$x; ?>" type="text" pattern="^[+-]?[0-9].[0-9]{0,2}" name="unitprice[<?php echo $x; ?>]"  value="<?php echo number_format($unitprice_array[$x], 2); ?>" placeholder="0.00" required /> <!-- min="-9999999999.99" max="9999999999.99" "-->
								<?php
								echo '</td>';
								
								echo '<td class="bodyBody bodyBodyRight textAlignRight">';
								?>
									<input class="totalPrice textAlignRight" onfocus="document.getElementById('current_row').value='<?php echo $row; ?>';" id="totalprice_<?php echo $row; ?>" tabindex="<?php echo ($row*14)+$x; ?>" type="text" pattern="[0-9].[0-9]{0,2}" name="totalprice[<?php echo $x; ?>]" size="15" maxlength="25" value="<?php echo $totalprice_array[$x] ?>" required />
								<?php
								echo '</td>';
								echo '</tr>';
							 } ?>							
						</tbody>
						
						</table>
					</td>
					<td>
						<!-- Other info goes here -->
					</td>
				</tr>
			</tbody>
		</table>
	</form>
</div>