<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
	<div class="wrap">
		<h2><?php echo $page_title; ?></h2>
		<?php 
			if($new_property == 'false'){
				echo '<a class="ui-button ui-widget ui-corner-all" href="'.admin_url("admin.php").'?page=properties-page&property_add_new=true'.'" > Add New </a>'; 
			} ?>
		<br/>
		<br/>
		<form id="service_crm_property_form_id"  action="<?php echo admin_url( 'admin.php' ); ?>" method="post">
			<input type="hidden" name="action" value="<?php echo $page_action; ?>" />
			<input type="hidden" name="proprty_add_new" value="<?php echo $new_property; ?>" />
			<input type="hidden" name="id" value="<?php echo $property_id; ?>" />
			<input type="hidden" id="service_crm_invoice_properties_company_id" name="company_id" value="<?php echo $property_company_id; ?>" />
			<p>Use this table to select the correct company to associte to this property.</p>
			<input type="button" class="ui-button ui-widget ui-corner-all" id="show_hide_companies_button" value="Hide Companies Table" />
			<?php 
			$company_name = "";
			if(!empty($property_company_id)){
				$company_name = $this->service_crm_invoice_get_company_name($property_company_id);
			} 
			$service_crm_invoice_companies = $this->service_crm_invoice_get_company_data(null);
			
			
			/* <select id="company_id" name="company_id"><?php echo $this->service_crm_invoice_company_dropdown($property_company_id); ?></select> */ ?>
			<div id="show_hide_companies">
			<table id="service_crm_invoice_companies_properties" cellpadding="0" cellspacing="0" border="0">
				<thead>
					<tr>
						<th>ID</th>
						<th>Company</th>
						<th>Address1</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($service_crm_invoice_companies as $company){
					?>
					<tr>
						<td><input class="service_crm_invoice_company_id_select ui-button ui-widget ui-corner-all" data="<?php echo $company->id; ?>" data_company_name="<?php echo $company->name; ?>" type="button" value="Select Company" /></td> 
						<td><?php echo $company->name; ?></td>
						<td><?php echo $company->address1; ?></td>
					</tr>
					<?php 
					}
					?>
				<tbody>
			</table>
			</div>
			<br/>
			<label for="service_crm_invoice_property_company_name">Company </label>
			<input id="service_crm_invoice_property_company_name" name="company_name" type="text" disabled size="50" value="<?php echo $company_name;?>" />
				<?php /*if( $getInvoice === true){ ?>
					<label for="invoiceId">Invoice </label>
					<select id="invoiceId" name="innvoice_id"><?php echo InvoiceDropdown($property_id); ?></select>
				<?php } */?>
			<br/>
			<label for="property_name">Property Name </label><input id="property_name" type="text" name="name" required placeholder="Property name" size="50" value="<?php echo $property_name; ?>" />
			<br />
			<label for="property_address1">Address1 </label><input id="property_address1" type="text" name="address1" required placeholder="Property address" size="50" value="<?php echo $property_address1; ?>" />
			<br />
			<label for="property_address2">Address2 </label><input id="property_address2" type="text" name="address2" placeholder="Property address" size="50" value="<?php echo $property_address2; ?>" />
			<br />
			<label for="property_address3">Address3 </label><input id="property_address3" type="text" name="address3" placeholder="Property address" size="50" value="<?php echo $property_address3; ?>" />
			<br />
			<label for="property_city">City </label><input id="property_city" type="text" name="city" required placeholder="Property city" size="50" value="<?php echo $property_city; ?>" />
			<br />
			<label for="property_state">State </label>
			<select id="property_state" name="state"><?php echo $this->StateDropdown($property_state, 'abbrev'); ?></select>
			<br />
			<label for="property_zip">Zip </label><input id="property_zip" type="text" name="zip" required placeholder="Property zip" size="10" value="<?php echo $property_zip; ?>" />
			<br />
			<label for="property_country">Country </label><input id="property_country" type="text" name="country" required placeholder="Property County" size="50" value="<?php echo $property_country; ?>" />
			<br />
			<label for="property_phone1">Phone 1 </label><input id="property_phone1" class="phone" type="tel" name="phone1" required placeholder="Property phone" size="14" value="<?php echo $property_phone1; ?>" />
			<br />
			<label for="property_phone2">Phone 2 </label><input id="property_phone2" class="phone" type="tel" name="phone2" placeholder="Property phone" size="14" value="<?php echo $property_phone2; ?>" />
			<br />
			<label for="property_note1">Note 1 </label><textarea id="property_note1" name="note1" cols="50" rows="4" maxlength="255"><?php echo $property_note1; ?></textarea>
			<br />
			<label for="property_note2">Note 2 </label><textarea id="property_note2" name="note2" cols="50" rows="4" maxlength="255"><?php echo $property_note2; ?></textarea>
			<input class="ui-button ui-widget ui-corner-all" type="Submit" />
		</form>
	</div>