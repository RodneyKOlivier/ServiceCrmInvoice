<?php
/* if(class_exists('Service_Crm_Invoice_Admin')){
	echo "Class Exists";
	
	$plugin_admin = new Service_Crm_Invoice_Admin();*/
/* $class_methods = get_class_methods($plugin_admin); 
var_dump($class_methods);  */
	/*  0 => string '__construct' (length=11)
  1 => string 'enqueue_styles' (length=14)
  2 => string 'enqueue_scripts' (length=15)
  3 => string 'add_plugin_admin_menu' (length=21)
  4 => string 'service_crm_invoice_settings_page' (length=33)
  5 => string 'service_crm_invoice_companies_page' (length=34)
  6 => string 'service_crm_invoice_properties_page' (length=35)
  7 => string 'service_crm_invoice_invoices_page' (length=33)
  8 => string 'add_action_links' (length=16)
  9 => string 'StateDropdown' (length=13)
  10 => string 'check_select' (length=12)
*/
	//require_once '..\class-service-crm-invoice-admin.php';
//} else {
//	echo "Class Does Not Exist";
//}
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/admin/partials
 */
 
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
	<div class="wrap">
		<form action="<?php echo admin_url( 'admin.php' ); ?>" method="post"> <!-- .'?page=sub-page4' -->
			<input name="action" type="hidden" value="service_crm_invoice_setting_update" />
			<input name="id" type="hidden" value="<?php echo $id; ?>" />
			<fieldset>
                <legend class="screen-reader-text"><span><?php esc_attr_e('Login Logo', $this->plugin_name);?></span></legend>
                <label for="<?php echo $this->plugin_name;?>-login_logo">
                    <input type="hidden" id="login_logo_id" name="<?php echo $this->plugin_name;?>[login_logo_id]" value="<?php echo $login_logo_id; ?>" />
                    <input id="upload_login_logo_button" type="button" class="ui-button ui-widget ui-corner-all" value="<?php _e( 'Upload Logo', $this->plugin_name); ?>" />
                    <span><?php esc_attr_e('Login Logo', $this->plugin_name);?></span>
                </label>
                <div id="upload_logo_preview" class="wp_cbf-upload-preview <?php if(empty($login_logo_id)) echo 'hidden'?>">
                    <img src="<?php echo $login_logo_url; ?>" />
                    <button id="wp_cbf-delete_logo_button" class="wp_cbf-delete-image">X</button>
                </div>
            </fieldset>
			
			
			<?php if(!empty($logo_url)){echo "<image class='logo' src='$logo_url' alt='logo' ><br/>";} ?>
			<label for="logo_url">Logo </label><input id="logo_url" name="logo_url" type="url" size="100" value="<?php echo $logo_url; ?>" /><br/>
			<label for="title_name">Title </label><input id="title_name" name="title_name" type="text" size="100" value="<?php echo $title_name; ?>" /><br/>
			<label for="title_tag">Tag </label><input id="title_tag" name="title_tag" type="text" size="100" value="<?php echo $title_tag; ?>" /><br/>
			<label for="address1">Address 1 </label><input id="address1" name="address1" type="text" size="100" value="<?php echo $address1; ?>" /><br/>
			<label for="address2">Address 2 </label><input id="address2" name="address2" type="text" size="100" value="<?php echo $address2; ?>" /><br/>
			<label for="city">City </label><input id="city" name="city" type="text" size="59" value="<?php echo $city; ?>" />,&nbsp;
			 State <select id="state" name="state"><?php echo $this->StateDropdown($state, 'abbrev'); ?></select>
			 Zip <input id="zip" name="zip" type="text" size="15" value="<?php echo $zip; ?>" /><br/>
			<label for="phone1">Phone 1 </label><input id="phone1" class="phone" name="phone1" type="tel" size="25" value="<?php echo $phone1; ?>" /><br/>
			<label for="phone2">Phone 2 </label><input id="phone2" class="phone" name="phone2" type="tel" size="25" value="<?php echo $phone2; ?>" /><br/>
			<label for="fax">Fax </label><input id="fax" class="phone" name="fax" type="tel" size="25" value="<?php echo $fax; ?>"/><br/>
			<input type="submit" class="ui-button ui-widget ui-corner-all" value="Save" />
		</form>
	</div>																							