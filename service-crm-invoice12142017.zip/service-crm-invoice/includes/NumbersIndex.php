<?php // Silence is golden
include "autoload.php";
//echo 'Here<br>';
$num = $_GET['grand_total'];

//var_dump($num);
echo Numbers_Words::toCurrency($num,"en_US", "USD");
/*return Numbers_Words::toCurrency($num,"en_US", "USD"); */