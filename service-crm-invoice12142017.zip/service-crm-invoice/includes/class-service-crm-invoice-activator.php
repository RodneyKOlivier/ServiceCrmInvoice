<?php

/**
 * Fired during plugin activation
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/includes
 * @author     Rodney Olivier <rodneyolivier@live.com>
 */
class Service_Crm_Invoice_Activator {

    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since    1.0.0
     */
    public static function activate() {
        global $wpdb;
        if( is_admin() ) {
            $company_table_name = $wpdb->prefix . "service_crm_invoice_company";
            $contact_table_name = $wpdb->prefix . "service_crm_invoice_contact"; 
            $properties_table_name = $wpdb->prefix . "service_crm_invoice_properties";
            $invoice_table_name = $wpdb->prefix . "service_crm_invoice_invoices";
            $settings_table_name = $wpdb->prefix. "service_crm_invoice_settings";
            $session_save_temp_table = $wpdb->prefix."service_crm_invoice_session_temp";

            $charset_collate = $wpdb->get_charset_collate();

            $session_sql = "CREATE TABLE IF NOT EXISTS $session_save_temp_table (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                savesession TEXT,
                PRIMARY KEY  (id)
            ) $charset_collate;";
            $customer_sql = "CREATE TABLE IF NOT EXISTS $company_table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                user_id mediumint(9),
                name tinytext NOT NULL,
                address1 tinytext NOT NULL,
                address2 tinytext,
                address3 tinytext,
                city tinytext NOT NULL,
                state varchar(2) NOT NULL,
                zip varchar(10) NOT NULL,
                country tinytext NOT NULL,
                phone1 varchar(14) NOT NULL,
                phone2 varchar(14),
                phone3 varchar(14),
                fax varchar(14),
                note1 text NOT NULL,
                note2 text NOT NULL,
                url varchar(255) DEFAULT '' NOT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;";
            $contact_sql = "CREATE TABLE IF NOT EXISTS $contact_table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                company_id mediumint(9),
                name tinytext NOT NULL,
                address1 tinytext NOT NULL,
                address2 tinytext,
                address3 tinytext,
                city tinytext NOT NULL,
                state varchar(2) NOT NULL,
                zip varchar(10) NOT NULL,
                country tinytext NOT NULL,
                phone1 varchar(14) NOT NULL,
                phone2 varchar(14),
                note1 text NOT NULL,
                note2 text NOT NULL,
                PRIMARY KEY  (id),
                FOREIGN KEY (company_id) REFERENCES $company_table_name(id)
            ) $charset_collate;";
            $property_sql = "CREATE TABLE IF NOT EXISTS $properties_table_name(
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                company_id mediumint(9),
                name tinytext NOT NULL,
                address1 tinytext NOT NULL,
                address2 tinytext,
                address3 tinytext,
                city tinytext NOT NULL,
                state varchar(2) NOT NULL,
                zip varchar(10) NOT NULL,
                country tinytext NOT NULL,
                phone1 varchar(14) NOT NULL,
                phone2 varchar(14),
                note1 text NOT NULL,
                note2 text NOT NULL,
                PRIMARY KEY  (id),
                FOREIGN KEY (company_id) REFERENCES $company_table_name(id)
            ) $charset_collate;";

            $invoice_sql = "CREATE TABLE IF NOT EXISTS $invoice_table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                property_id mediumint(9) NOT NULL,
                company_id mediumint(9) NOT NULL,
                invoice_number int(9) NOT NULL,
                invoice_date datetime NOT NULL,
                salesperson VARCHAR(25),
                po_number VARCHAR(25),
                requisitioner VARCHAR(100),
                fob_point VARCHAR(25),
                terms VARCHAR(25),
                pay_status VARCHAR(25) NOT NULL DEFAULT 'unpaid',
                invoice_details text NOT NULL,
                comments text VARCHAR(255),
                agreement_type VARCHAR(25),
                invoice_type VARCHAR(25),
                invoice_due_date datetime,
                PRIMARY KEY (id),
                FOREIGN KEY (property_id) REFERENCES $properties_table_name(id)
            ) $charset_collate;";

            $settings_sql = "CREATE TABLE IF NOT EXISTS $settings_table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                logo_url VARCHAR(255),
                title_name VARCHAR(255),
                title_tag VARCHAR(255),
                address1 VARCHAR(255),
                address2 VARCHAR(255),
                city VARCHAR(255),
                state VARCHAR (50),
                zip VARCHAR(25),
                phone1 VARCHAR(25),
                phone2 VARCHAR(25),
                fax VARCHAR(25),
                PRIMARY KEY (id)
            ) $charset_collate";
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            dbDelta( $customer_sql );
            dbDelta( $contact_sql );
            dbDelta( $property_sql );
            dbDelta( $invoice_sql );
            dbDelta( $settings_sql );
            dbDelta( $session_sql );

        }
    }
}
