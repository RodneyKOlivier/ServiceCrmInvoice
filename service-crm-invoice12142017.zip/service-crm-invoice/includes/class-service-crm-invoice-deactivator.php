<?php

/**
 * Fired during plugin deactivation
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/includes
 * @author     Rodney Olivier <rodneyolivier@live.com>
 */
class Service_Crm_Invoice_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
