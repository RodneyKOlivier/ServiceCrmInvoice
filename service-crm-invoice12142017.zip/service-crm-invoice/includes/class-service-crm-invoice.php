<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/includes
 * @author     Rodney Olivier <rodneyolivier@live.com>
 */
class Service_Crm_Invoice {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Service_Crm_Invoice_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'PLUGIN_NAME_VERSION' ) ) {
			$this->version = PLUGIN_NAME_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'service-crm-invoice';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Service_Crm_Invoice_Loader. Orchestrates the hooks of the plugin.
	 * - Service_Crm_Invoice_i18n. Defines internationalization functionality.
	 * - Service_Crm_Invoice_Admin. Defines all hooks for the admin area.
	 * - Service_Crm_Invoice_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-service-crm-invoice-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-service-crm-invoice-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-service-crm-invoice-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-service-crm-invoice-public.php';

		/**
		*	include module to convert numbers to words
		*/
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/autoload.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/Numbers/Words.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/Numbers/Locale/en/US.php';
		$this->loader = new Service_Crm_Invoice_Loader();
		}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Service_Crm_Invoice_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Service_Crm_Invoice_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Service_Crm_Invoice_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		
		//Plugin Menu
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_plugin_admin_menu' );

		// Add Settings link to the plugin
		$plugin_basename = plugin_basename( plugin_dir_path( __DIR__ ) . $this->plugin_name . '.php' );

		// Add link to settings page at plugins list
		$this->loader->add_filter( 'plugin_action_links_' . $plugin_basename, $plugin_admin, 'add_action_links' );
		
		
		// Save/Update Settings Data
		$this->loader->add_action('admin_action_service_crm_invoice_setting_update', $plugin_admin, 'service_crm_invoice_setting_update');
		
		// Save Company Data
		$this->loader->add_action('admin_action_service_crm_invoice_company_update', $plugin_admin, 'service_crm_invoice_company_update');
		
		//Update Company Data
		$this->loader->add_action('admin_action_service_crm_invoice_edit_company' , $plugin_admin, 'service_crm_invoice_company_update');
		
		// Save Property Data
		$this->loader->add_action('admin_action_service_crm_invoice_property_update', $plugin_admin, 'service_crm_invoice_property_update');
		
		// Update Property Data
		$this->loader->add_action('admin_action_service_crm_invoice_property_edit', $plugin_admin, 'service_crm_invoice_properties_page');
		
		// Get Invoice Pre-Data
		//$this->loader->add_action('admin_action_service_crm_invoice_edit_invoice', $plugin_admin, 'service_crm_invoice_invoice_page' );
		$this->loader->add_action('admin_action_service_crm_invoice_edit_invoice', $plugin_admin, 'service_crm_invoice_invoices_page' );
		
		
		// Save/Update invoice data
		$this->loader->add_action('admin_action_service_crm_invoice_invoice_update', $plugin_admin, 'service_crm_invoice_invoice_update' );
	}
	
	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {
//service_crm_invoice_edit_invoice
		$plugin_public = new Service_Crm_Invoice_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		
		$this->loader->add_action( 'init', $plugin_public, 'register_shortcodes' );
		
		$this->loader->add_action('public_action_service_crm_invoice_select_company', $plugin_public, 'service_crm_invoice_public_invoices' ); //service_crm_invoice_public_invoices
		//$this->loader->add_action('public_action_service_crm_invoice_public_invoices', $plugin_public, 'service_crm_invoice_public_invoices');

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Service_Crm_Invoice_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
