<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/public
 * @author     Rodney Olivier <rodneyolivier@live.com>
 */
class Service_Crm_Invoice_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	
	

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Service_Crm_Invoice_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Service_Crm_Invoice_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		
		
		/*wp_enqueue_style( $this->plugin_name.'-data-tables', plugin_dir_url( __FILE__ ) . 'css/datatables.min.css', array(), $this->version, 'all' );*/
		wp_enqueue_style( $this->plugin_name.'-data-tables', plugin_dir_url( __FILE__ ) . 'css/DataTablesCustom/datatables.min.css', array(), $this->version, 'all' );
		
		wp_enqueue_style( 'wp-color-picker' );            
        
		wp_enqueue_style( $this->plugin_name.'-jquery-ui-css', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/redmond/jquery-ui.css', array(), $this->version, 'all' );
		
		//wp_enqueue_style( $this->plugin_name.'-admin-css', plugin_dir_url( __FILE__ ) . 'css/service-crm-invoice-admin.css', array( 'wp-color-picker' ), $this->version, 'all' );

		wp_enqueue_style( $this->plugin_name.'public-css', plugin_dir_url( __FILE__ ) . 'css/service-crm-invoice-public.css', array( 'wp-color-picker' ), $this->version, 'all' );
		
		wp_enqueue_style($this->plugin_name.'-font-Arizonia', 'http://fonts.googleapis.com/css?family=Arizonia', array(), $this->version, 'all' );
		//<link href='http://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet' type='text/css'>
		
		wp_enqueue_style($this->plugin_name.'-font-Courgette', 'http://fonts.googleapis.com/css?family=Courgette', array(), $this->version, 'all' );
		//<link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
		wp_enqueue_style($this->plugin_name.'-font-Roboto', 'http://fonts.googleapis.com/css?family=Roboto:400i', array(), $this->version, 'all' );
		//<link href="https://fonts.googleapis.com/css?family=Roboto:400i" rel="stylesheet">
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Service_Crm_Invoice_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Service_Crm_Invoice_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		
		wp_enqueue_media();

		//wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/service-crm-invoice-admin.js', array( 'jquery' ), $this->version, false );
		
		wp_enqueue_script( $this->plugin_name.'-masked-input-js', plugin_dir_url( __FILE__ ) . 'js/jquery.maskedinput.min.js', array('jquery' ), $this->version, false );
		
		wp_enqueue_script( $this->plugin_name.'-jquery-ui-js', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js', array('jquery' ), $this->version, false );
		
		/*wp_enqueue_script( $this->plugin_name.'-datatable-js', plugin_dir_url( __FILE__ ) . 'js/datatables.min.js', array('jquery' ), $this->version, false );*/
		wp_enqueue_script( $this->plugin_name.'-datatable-js', plugin_dir_url( __FILE__ ) . 'css/DataTablesCustom/datatables.min.js', array('jquery' ), $this->version, false );
		

		
		//wp_enqueue_script( $this->plugin_name.'-admin-js', plugin_dir_url( __FILE__ ) . 'js/service-crm-invoice-admin.js', array( 'jquery', 'wp-color-picker' ), $this->version, false );
		
		wp_enqueue_script( $this->plugin_name.'-public-js', plugin_dir_url( __FILE__ ) . 'js/service-crm-invoice-public.js', array( 'jquery' ), $this->version, false );//,'wp-color-picker'

	}
	
	public function register_shortcodes() {
		add_shortcode( 'public_invoices', array( $this, 'service_crm_invoice_public_invoices' ) );
	}

	public function service_crm_invoice_public_list_companies_page($select_service_crm_companies=null){
		// Show list of companies to select from for viewing invoices.
		$url_get_vars = '';
		$page_title = 'Select a Company';
		$page_action = 'service_crm_invoice_select_company';
		
		// need to accomidate if we are in the admin or public side of the site. or re-create these functions in the publice class.
		?>
		<div class="wrap">
			<h2><?php echo $page_title;?></h2>
			<div class='data_table_wrap'>
				<form id="service_crm_invoice_public_company_list_form" action="<?php echo esc_url($url_get_vars); ?>" method="post">
				<input type="hidden" id="service_crm_invoice_public_company_id" name="company_id" value="" />
				<input type="hidden" name="action" value="<?php echo $page_action; ?>" />
				<table id="service_crm_invoice_customer_datatable" >
					<thead>
						<tr>
							<th>ID</th>
							<th>Company</th>
							<th>Address1</th>
						</tr>
					</thead>
					<tbody>
					<?php
						foreach ($select_service_crm_companies as $company)
						{
							?>
							<tr>
								<td>
								<?php /* <input class="service_crm_invoice_public_company_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $company->id; ?>" type="button" value="Select Company" /> */?>
								<span class="service_crm_invoice_public_company_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $company->id; ?>" >Select Company</span>
								
								</td> 
								<td><?php echo $company->name; ?></td>
								<td><?php echo $company->address1; ?></td>
							</tr>
							<?php
						}
					?>
					</tbody>
				</table>
				</form>
			</div>
		</div>
		<?php
	}
	
	public function service_crm_invoice_public_list_properties_page($select_service_crm_invoice_properties, $company_id = null ){
	// Show list of properties to select from for viewing invoices.
		$url_get_vars = '';
		$page_title = 'Select a Property';
		$page_action = 'service_crm_invoice_select_company';
	?>
		<div class="wrap">
			<h2>
			<?php
				echo $page_title;
			?>
			</h2>
			
			<form id="service_crm_invoice_public_property_list_form" action="<?php echo esc_url($url_get_vars);?>" method="post">
			<input type="hidden" id="service_crm_invoice_public_property_id" name="property_id" value="" />
			<input type="hidden" name="action" value="<?php echo $page_action; ?>" />
			<input type="hidden" id="service_crm_invoice_property_list_company_id" name="company_id" value="<?php echo $company_id; ?>" />
			<table id="service_crm_invoice_property_datatable" >
				<thead>
					<tr>
						<th>ID</th>
						<th>Company</th>
						<th>Name</th>
						<th>Address1</th>
					</tr>
				</thead>
				<tbody>
				<?php
					foreach ($select_service_crm_invoice_properties as $property)
					{
						?>
						<tr>
							<td>
							<?php /* <input class="service_crm_invoice_public_property_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $property->id; ?>" type="button" value="Select Property" /> */ ?>
							<span class="service_crm_invoice_public_property_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $property->id; ?>" >Select Property</span>
							</td> 
							<td><?php echo $this->service_crm_invoice_get_company_name($property->company_id);?></td>
							<td><?php echo $property->name; ?></td>
							<td><?php echo $property->address1; ?></td>
						</tr>
						<?php
					}
				?>
				</tbody>
			</table>
			</form>
		</div>
		<?php
	}
	
	public function service_crm_invoice_public_list_invoice_page($service_crm_invoice_invoices, $company_id=null, $property_id=null ){
		// Show list of invoices to select from for viewing an invoice.
		$url_get_vars = '';
		$page_title = 'Select  an Invoice ';
		$page_action = 'service_crm_invoice_select_company';
	?>
		<div class="wrap">
			<h2>
			<?php
				echo $page_title;
			?>
			</h2>
<!-- check the value set by show_addnew_button -->			
			<form id="service_crm_invoice_public_invoices_list_form" action="<?php echo esc_url($url_get_vars); ?>" method="post">
			<input type="hidden" name="action" value="<?php echo $page_action; ?>" />
			<input type="hidden" id="service_crm_invoice_public_property_id" name="property_id" value="<?php echo $property_id; ?>" />
			<input type='hidden' id='service_crm_invoice_public_company_id' name='company_id' value='<?php echo $company_id; ?>' />
			<input type='hidden' id='service_crm_invoice_public_invoice_id' name='invoice_id' value='' />
			<table id="service_crm_invoice_invoice_datatable" >
				<thead>
					<tr>
						<th>Select</th>
						<th>Company</th>
						<th>Property</th>
						<th>Invoice Num.</th>
						<th>Invoice Date</th>
					</tr>
				</thead>
				<tbody>
				<?php
					foreach ($service_crm_invoice_invoices as $invoice)
					{ ?>
						<tr>
							<td>
							<?php /* <input class="service_crm_invoice_public_invoice_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $invoice->id ?>" type="button" value="Select Invoice" /> */?>
							<span class="service_crm_invoice_public_invoice_list_submit ui-button ui-widget ui-corner-all" data="<?php echo $invoice->id ?>">Select Invoice</span>
							</td>
							<td><?php echo $this->service_crm_invoice_get_company_name($invoice->company_id) ; ?></td>
							<td><?php echo $this->service_crm_invoice_get_property_name($invoice->property_id); ?></td>
							<td><?php echo $invoice->invoice_number; ?></td>
							<td><?php echo date('m/d/Y', strtotime($invoice->invoice_date)); ?></td>
						</tr>
						<?php
					}
				?>
				</tbody>
			</table>
			</form>
		</div>
		<?php
		
	}
	
	public function service_crm_invoice_public_invoices(){
		ob_start();
		
		$add_new_invoice = false;
		
		if (empty($_POST)){
			$select_service_crm_companies = Service_Crm_Invoice_Admin::service_crm_invoice_get_company_data(null);
			$this->service_crm_invoice_public_list_companies_page($select_service_crm_companies);
		} elseif(isset($_POST['company_id']) && !isset($_POST['property_id']) ){
//var_dump($_POST);die();
			$company_id = $_POST['company_id'];
			$select_service_crm_properties = Service_Crm_Invoice_Admin::service_crm_invoice_get_property_data(null, $company_id);
			$this->service_crm_invoice_public_list_properties_page($select_service_crm_properties,$company_id);
		} elseif(isset($_POST['company_id']) && isset($_POST['property_id']) && !isset($_POST['invoice_id']) ){
			$company_id = $_POST['company_id'];
			$property_id = $_POST['property_id'];
			$select_service_crm_invoices = Service_Crm_Invoice_Admin::service_crm_invoice_get_invoice_data(null, $property_id);
			$this->service_crm_invoice_public_list_invoice_page($select_service_crm_invoices, $company_id, $property_id);
		} elseif( isset($_POST['invoice_id'])){
			$company_id = $_POST['company_id'];
			$property_id = $_POST['property_id'];
			$invoice_id = $_POST['invoice_id'];
			$select_service_crm_invoices = Service_Crm_Invoice_Admin::service_crm_invoice_get_invoice_data($invoice_id , null);

			foreach($select_service_crm_invoices as $invoice){
				$invoice_id = $invoice->id;
				$company_id = $invoice->company_id;
				$property_id = $invoice->property_id;
				$invoice_number = $invoice->invoice_number;
				$invoice_date = $invoice->invoice_date;
				$salesperson = $invoice->salesperson;
				$po_number = $invoice->po_number;
				$requisitioner = $invoice->requisitioner;
				$fob_point = $invoice->fob_point;
				$terms = $invoice->terms;
				$pay_status = $invoice->pay_status;
				$comments = $invoice->comments;
				$agreement_type = $invoice->agreement_type;
				$invoice_type = $invoice->invoice_type;
				$invoice_due_date = $invoice->invoice_due_date;
				$invoice_details_json = $invoice->invoice_details;
			}
			$invoice_details_array = json_decode($invoice_details_json, true);
/* echo '<pre>';
var_dump($invoice_type,agreement_type,invoice_due_date);			
echo '</pre>'; */
			
			$invoice_details_array = json_decode($invoice_details_json, true);
			$quantity_array = $invoice_details_array['quantity'];
			$description_array = $invoice_details_array['description'];
			$unitprice_array = $invoice_details_array['unitprice'];
			$totalprice_array = $invoice_details_array['totalprice'];
			$subtotal = $invoice_details_array['subtotal'];
			$sales_tax = $invoice_details_array['sales_tax'];
			$ship_handle = $invoice_details_array['ship_handle'];
			$grand_total = $invoice_details_array['grand_total'];
			
			$num_to_words = new Numbers_Words();
			$numWordsGrandTotal = $num_to_words->toCurrency($grand_total,"en_US", "USD");
			
			$company_array = Service_Crm_Invoice_Admin::service_crm_invoice_get_company_data($company_id);
			$property_array = Service_Crm_Invoice_Admin::service_crm_invoice_get_property_data($property_id);
						
			$page_action = 'service_crm_invoice_invoice_update';
			$select_service_crm_invoice_settings = Service_Crm_Invoice_Admin::service_crm_invoice_get_settings();
			
			include_once( 'partials/service-crm-invoice-public-invoices-display.php' );
//var_dump($_POST);die();			
		}
		
		//include_once( 'partials/service-crm-invoice-public-display.php' );
	}
	
	function service_crm_invoice_get_company_name($property_company_id){
		$select_service_crm_invoice_company = Service_Crm_Invoice_Admin::service_crm_invoice_get_company_data($property_company_id);
		foreach($select_service_crm_invoice_company as $company){
			$company_name = $company->name;
			break;
		}
		return $company_name;
	}
	
	function service_crm_invoice_get_property_name($property_id){
		$select_service_crm_invoice_properties = Service_Crm_Invoice_Admin::service_crm_invoice_get_property_data($property_id);
		foreach($select_service_crm_invoice_properties as $property){
			$property_name = $property->name;
			break;
		}
		return $property_name;
	}
}
