(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	 $(document).ready( function(){
		$('#service_crm_invoice_customer_datatable').dataTable();
		$('#service_crm_invoice_invoices_datatable').dataTable();
		$('#service_crm_invoice_property_datatable').dataTable();
		$('#service_crm_invoice_invoice_datatable').dataTable();
		
		/* $('.paginate_button').addClass("ui-button ui-widget ui-corner-all"); */
	});
	
	$(document).on('click', '.service_crm_invoice_public_company_list_submit', function() {
		var dataVal = $(this).attr('data');
		$('#service_crm_invoice_public_company_id').val(function(){
			return dataVal;
		});
		$('#service_crm_invoice_public_company_list_form').submit();
	});
	
	$(document).on('click', '.service_crm_invoice_public_property_list_submit', function () {
		var datVal = $(this).attr('data');
		$('#service_crm_invoice_public_property_id').val(function(){
			return datVal;
		});
		$('#service_crm_invoice_public_property_list_form').submit();
	});
	
	$(document).on('click', '.service_crm_invoice_public_invoice_list_submit', function() {
		var dataVal  = $(this).attr('data'); 
		$('#service_crm_invoice_public_invoice_id').val( function(){
			return dataVal; 
		});
		$('#service_crm_invoice_public_invoices_list_form').submit();
	});
	
	$(document).ready(function(){
		window.onafterprint = function(e){
			/*$(window).off('mousemove', window.onafterprint);
			console.log('Print Dialog Closed..');*/
			$('#footer').show();
			$(' header#masthead').show();
			$('.entry-header').show();
			 console.log("Printing completed...");
		};
	});
	$(document).on('click','.print-button', function() {
		/*$('#headerimg').hide();*/
		$('#footer').hide();
		$(' header#masthead').hide();
		$('.entry-header').hide();
		/* $('hr:nth-child(2)').hide(); */
		/* $('#service_crm_invoice_invoice_header').hide(); */
		
		
		
		window.print();
		$('#footer').show();
		$(' header#masthead').show();
		$('.entry-header').show();		
		return false; // why false?
	});
	
	
})( jQuery );
