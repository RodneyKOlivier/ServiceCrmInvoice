<?php

//var_dump(get_class_methods('Service_Crm_Invoice_Admin'));
/* echo "<pre>";
var_dump($service_crm_invoice_companies,$select_service_crm_invoice_settings);
echo "</pre>"; */
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       wp-projects.rjolivier.com
 * @since      1.0.0
 *
 * @package    Service_Crm_Invoice
 * @subpackage Service_Crm_Invoice/public/partials
 */

/* echo '<pre>';
var_dump($property_array);
echo '</pre>'; */
 
	$setting_logo_url = '';
	$setting_title_name = '';
	$setting_title_tag = '';
	$setting_address1 = '';
	$setting_address2 = '';
	$setting_city = '';
	$setting_state = '';
	$setting_zip = '';
	$setting_phone1 = '';
	$setting_phone2 = '';
	$setting_fax = '';
	if( !empty($select_service_crm_invoice_settings) ){
		foreach( $select_service_crm_invoice_settings as $setting){
			$setting_logo_url = $setting->logo_url;
			$setting_title_name = $setting->title_name;
			$setting_title_tag = $setting->title_tag;
			$setting_address1 = $setting->address1;
			$setting_address2 = $setting->address2;
			$setting_city = $setting->city;
			$setting_state = $setting->state;
			$setting_zip = $setting->zip;
			$setting_phone1 = $setting->phone1;
			$setting_phone2 = $setting->phone2;
			$setting_fax = $setting->fax;
		}
	}
	
	foreach($property_array as $property){
		$property_name = $property->name;
		$property_address1= $property->address1;
		$property_address2= $property->address1;
		$property_city = $property->city;
		$property_state = $propert->state;
		$property_zip = $property->zip;
		$property_phone1 = $property->phone1;
		$property_phone2 = $property->phone2;
	}
	
	if(!empty($company_array)){
		foreach ($company_array as $company){
			$company_name = $company->name;
			$company_address1 = $company->address1;
			$company_address2 = $company->address2;
			$company_address3 = $company->address3;
			$company_city = $company->city;
			$company_state = $company->state;
			$company_zip = $company->zip;
			$company_country = $company->country;
			$company_phone1 = $company->phone1;
			$company_phone2 = $company->phone2;
			$company_phone3 = $company->phone3;
			$company_fax = $company->fax;
		}
	} else {
		$company_name = '';
		$company_address1 = '';
		$company_address2 = '';
		$company_address3 = '';
		$company_city = '';
		$company_state = '';
		$company_zip = '';
		$company_country = '';
		$company_phone1 = '';
		$company_phone2 = '';
		$company_phone3 = '';
		$company_fax = '';
	}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class='wrap'>
<!-- <h2 class='wp-heading-inline'><?php //echo $page_title; ?></h2> -->
	<a class='ui-button ui-widget ui-corner-all no-print' href="">HOME</a>
	<span class='print-button ui-button ui-widget ui-corner-all no-print'> PRINT </span>
	
	<table id="invoiceNewWrapper" cellspacing="0" cellpadding="0" border="0" >
		<thead>
			<tr id='service_crm_invoice_invoice_header' class='no-print'>
				<th colspan='2'>
					<h2 class='no-print'>Invoice For for Company: <STRONG><?php echo $company_name; ?></STRONG> for Property: <STRONG><?php echo$property_name;?></STRONG>
					</h2>
				</th>
			</tr>
			<tr>
				<td>
					<div class="display_block logo_wrap">
						<?php if( !empty($setting_logo_url) ){
							//html: <img src="smiley.gif" alt="Smiley face" height="42" width="42">
							//wordpress: get_image_tag( $id, $alt, $title, $align, $size ); // all params are required
							echo "<image src='$setting_logo_url' alt='logo' height='103' width='84'>";
						} else {
							echo '&nbsp';
						}
						?>
					</div>
					<div class="display_block">
						<?php
							echo '<strong>'.$setting_title_name.'</strong><br/>';
							echo $setting_address1.'<br/>';
							if(!empty($setting_address2)) {echo $setting_address2.'<br/>';}
							echo $setting_city.', '.$setting_state.' '.$setting_zip.'<br/>';
							echo $setting_phone1.'<br/>';
							if(!empty($setting_phone2)) {echo $setting_phone2.'<br/>';}
							if(!empty($setting_fax)) {echo $setting_fax.'<br/>';} 
						?>
					</div>
					<div class="display_block">
						<?php
							echo '<strong>'.$company_name.'</strong></br>';
							echo $company_address1.'<br/>';
							if (!empty($company_address2)){echo $company_address2.'<br/>';}
							if (!empty($company_address3)){echo $company_address3.'<br/>';}
							echo $company_city.',&nbsp;'.$company_state.'&nbsp;'.$company_zip.'&nbsp;'.$company_country.'<br/>';
							echo $company_phone1.'<br/>';
							if (!empty($company_phone2)) {echo $company_phone2.'<br/>';}
							if (!empty($company_phone3)) {echo $company_phone3.'<br/>';}
							if (!empty($company_fax)) {echo $company_fax.'<br/>';}
						?>
					</div>
					<div class="display_block">
						<?php 
							echo '<strong>'.$property_name.'</strong><br/>';
							echo $property_address1.'<br/>';
							if(!empty($property_address2)){echo $property_address2.'<br/>';}
							echo $property_city.',', $property_state.' '.$property_zip.'<br/>';
							echo $property_phone1.'<br/>';
							echo $property_phone2.'<br/>';
						?>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					<div class="display_block logo_wrap">
					<!-- left empty intentionally -->
					&nbsp;
					<!-- <img src="" width="96px"> -->
					</div>
					<div class="display_block">
						&nbsp;
					</div>
					<div class="display_block">
						&nbsp;
					</div>
					<div class="display_block textAlignRight">
						<h3>INVOICE</h3>
						Number: <?php echo $invoice_number; ?>
						<br />
						Date: <?php echo date('m/d/Y', strtotime($invoice_date)); ?>
						<br/>
						<!-- payment statue -->
						Payment Status: <?php echo $pay_status; ?>
					</div>
				</td>
			</tr>
			<tr>
				<td>
					<h2>COMMENTS OR SPECIAL INSTRUCTIONS:</h2>
					<?php echo $comments; ?>
				</td>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>
					<br/>
					<table id="invoiceNewInnerTable" cellspacing="0" cellpadding="2" border="0" >
					<thead>
						<tr>
							<th width="20%" class="blockHeader">SALES PERSON</th>
							<th width="15%" class="blockHeader">P.O. NUMBER</th>
							<th width="15%" class="blockHeader">REQUISITIONER</th>
							<th width="15%" class="blockHeader">SHIPPED VIA</th>
							<th width="15%" class="blockHeader">F.O.B. POINT</th>
							<th width="20%" class="blockHeader blockHeaderRight">TERMS</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td colspan="3">&nbsp;</td>
							<td colspan="2" class="textAlignRight">SUBTOTAL</td>
							<td class="blockBody blockBodyRight textAlignRight">
								$<?php echo $subtotal; ?>
							</td>
						</tr>
							<td colspan="3">&nbsp;</td>
							<td colspan="2" class="textAlignRight">SALESTAX</td>
							<td class="blockBody blockBodyRight textAlignRight">
								$<?php echo $sales_tax; ?>
							</td>
						<tr>
							<td colspan="3">&nbsp;</td>
							<td colspan="2" class="textAlignRight">SHIPPING & HANDLING</td>
							<td class="blockBody blockBodyRight textAlignRight">
								$<?php echo $ship_handle; ?>
							</td>
						</tr>
						<tr>
							<td colspan="3">&nbsp;</td>
							<td colspan="2" class="textAlignRight">TOTAL</td>
							<td class="blockBody blockBodyRight textAlignRight">
								$<?php echo $grand_total; ?>
							</td>
						</tr>
						<tr>
							<td colspan='6'>
								<p id="declaration">All Material is guaranteed to be as specified, and the above work was performed in accordance with the drawings and specifications provided for the above work and was completed in a substanial workmanlike manner for the aggreed sum of: <span class="underline" id="grandTotalWords"><?php echo ucwords($numWordsGrandTotal);?></span>&nbsp;<span class="underline" id="grandTotalNum">($<?php echo $grand_total; ?>)</span>.
								</p>
							</td>
						</tr>
						<tr>
						<td colspan="6">
							<p> This is a <?php if($invoice_type == 'partial'){ echo "Partial";} if($invoice_type == 'full'){ echo "Full";} ?> invoice due and payable by: <?php if(!empty($invoice_due_date)){echo date('m/d/Y', strtotime($invoice_due_date));} else { echo "__/__/_____";} ?> in accordance with our <span class="bold"><?php if($agreement_type == 'aggreement'){echo "Agreement";} if($agreement_type == 'proposal'){ echo "Proposal";} ?>.</span>
							<br />Respectfully Submitted: <span class="signature">William E. Oleen</span>
							</p>
						</td>
						</tr>
					</tfoot>
					<tbody>
						<tr>
							<td class="blockBody">
								<?php echo $salesperson; ?>
							</td>
							<td class="blockBody">
								<?php echo $po_number; ?>
							</td>
							<td class="blockBody">
								<?php echo $property_name; ?>
							</td>
							<td class="blockBody">
								<?php echo $ship_vai; ?>
							</td>
							<td class="blockBody">
								<?php echo $fob_point; ?>
							</td>
							<td class="blockBody blockBodyRight">
								<?php echo $terms; ?>
							</td>
						</tr>
						<tr>
							<td colspan="6" class="textAlignRight">
								&nbsp;
							</td>
						</tr>
						<tr>
							<th class="bodyHeader">QUANTITY</th>
							<th colspan="3" class="bodyHeader">DESCRIPTION OF WORK PERFORMED/SUPPLIES</th>
							<th class="bodyHeader">UNIT PRICE</th>
							<th class="bodyHeader bodyHeaderRight">TOTAL</th>
						</tr>

						<!-- repeating zone -->
						<?php for( $x = 0; $x < count($quantity_array); $x++){ ?>
							<tr>
								<td class="bodyBody">
									<?php echo $quantity_array[$x]; ?>
								</td>
								<td colspan="3" class="bodyBody">
									<?php echo $description_array[$x]; ?>
								</td>
								<td class="bodyBody textAlignRight">
									$<?php echo $unitprice_array[$x]; ?>
								</td>
							
								<td class="bodyBody bodyBodyRight textAlignRight">
									$<?php echo $totalprice_array[$x] ?>
								</td>
							</tr>
						 <?php } ?>
					</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</div>
