<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wp-projects.rjolivier.com
 * @since             1.0.0
 * @package           Service_Crm_Invoice
 *
 * @wordpress-plugin
 * Plugin Name:       Service CRM and Invoicing
 * Plugin URI:        wp-projects.rjolivier.com
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Rodney Olivier
 * Author URI:        wp-projects.rjolivier.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       service-crm-invoice
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'PLUGIN_NAME_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-service-crm-invoice-activator.php
 */
function activate_service_crm_invoice() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-service-crm-invoice-activator.php';
	Service_Crm_Invoice_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-service-crm-invoice-deactivator.php
 */
function deactivate_service_crm_invoice() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-service-crm-invoice-deactivator.php';
	Service_Crm_Invoice_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_service_crm_invoice' );
register_deactivation_hook( __FILE__, 'deactivate_service_crm_invoice' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-service-crm-invoice.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_service_crm_invoice() {

	$plugin = new Service_Crm_Invoice();
	$plugin->run();

}
run_service_crm_invoice();
